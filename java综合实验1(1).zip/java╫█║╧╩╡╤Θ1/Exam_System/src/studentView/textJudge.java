/*
 * textJudge.java
 *
 * Created on __DATE__, __TIME__
 */

package studentView;

import javax.swing.JPanel;

/**
 *
 * @author  __USER__
 */
public class textJudge extends javax.swing.JPanel {

	/** Creates new form textJudge */
	public textJudge(String id, JPanel pre, JPanel next) {
		initComponents();
		if (pre == null) {
			jButton7.setEnabled(false);

		}
		jButton9.setEnabled(false);
	}

	//GEN-BEGIN:initComponents
	// <editor-fold defaultstate="collapsed" desc="Generated Code">
	private void initComponents() {

		jTabbedPane1 = new javax.swing.JTabbedPane();
		jPanel1 = new javax.swing.JPanel();
		jLabel1 = new javax.swing.JLabel();
		jCheckBox1 = new javax.swing.JCheckBox();
		jCheckBox2 = new javax.swing.JCheckBox();
		jButton7 = new javax.swing.JButton();
		jButton8 = new javax.swing.JButton();
		jButton9 = new javax.swing.JButton();

		setBackground(new java.awt.Color(255, 255, 255));

		jLabel1.setFont(new java.awt.Font("Microsoft YaHei UI", 0, 21));
		jLabel1
				.setText("\u8ba1\u7b97\u673a\u80fd\u76f4\u63a5\u8bc6\u522b\u6c47\u7f16\u8bed\u8a00\u7a0b\u5e8f");

		jCheckBox1.setFont(new java.awt.Font("Microsoft YaHei UI", 0, 24));
		jCheckBox1.setText("\u6b63\u786e");

		jCheckBox2.setFont(new java.awt.Font("Microsoft YaHei UI", 0, 24));
		jCheckBox2.setText("\u9519\u8bef");

		jButton7.setBackground(new java.awt.Color(102, 153, 255));
		jButton7.setFont(new java.awt.Font("Microsoft YaHei UI", 0, 21));
		jButton7.setForeground(new java.awt.Color(255, 255, 255));
		jButton7.setText("\u4e0a\u4e00\u9898");
		jButton7.setBorderPainted(false);
		jButton7.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				jButton7ActionPerformed(evt);
			}
		});

		jButton8.setBackground(new java.awt.Color(102, 153, 255));
		jButton8.setFont(new java.awt.Font("Microsoft YaHei UI", 0, 21));
		jButton8.setForeground(new java.awt.Color(255, 255, 255));
		jButton8.setText("\u4fdd\u5b58");
		jButton8.setBorderPainted(false);
		jButton8.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				jButton8ActionPerformed(evt);
			}
		});

		jButton9.setBackground(new java.awt.Color(102, 153, 255));
		jButton9.setFont(new java.awt.Font("Microsoft YaHei UI", 0, 21));
		jButton9.setForeground(new java.awt.Color(255, 255, 255));
		jButton9.setText("\u4e0b\u4e00\u9898");
		jButton9.setBorderPainted(false);
		jButton9.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				jButton9ActionPerformed(evt);
			}
		});

		javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(
				jPanel1);
		jPanel1.setLayout(jPanel1Layout);
		jPanel1Layout
				.setHorizontalGroup(jPanel1Layout
						.createParallelGroup(
								javax.swing.GroupLayout.Alignment.LEADING)
						.addGroup(
								jPanel1Layout
										.createSequentialGroup()
										.addGap(52, 52, 52)
										.addGroup(
												jPanel1Layout
														.createParallelGroup(
																javax.swing.GroupLayout.Alignment.LEADING)
														.addGroup(
																javax.swing.GroupLayout.Alignment.TRAILING,
																jPanel1Layout
																		.createSequentialGroup()
																		.addComponent(
																				jCheckBox1)
																		.addPreferredGap(
																				javax.swing.LayoutStyle.ComponentPlacement.RELATED,
																				165,
																				Short.MAX_VALUE)
																		.addGroup(
																				jPanel1Layout
																						.createParallelGroup(
																								javax.swing.GroupLayout.Alignment.LEADING)
																						.addComponent(
																								jCheckBox2)
																						.addGroup(
																								jPanel1Layout
																										.createSequentialGroup()
																										.addComponent(
																												jButton7)
																										.addPreferredGap(
																												javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																										.addComponent(
																												jButton8,
																												javax.swing.GroupLayout.PREFERRED_SIZE,
																												113,
																												javax.swing.GroupLayout.PREFERRED_SIZE)
																										.addPreferredGap(
																												javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																										.addComponent(
																												jButton9))))
														.addComponent(
																jLabel1,
																javax.swing.GroupLayout.PREFERRED_SIZE,
																460,
																javax.swing.GroupLayout.PREFERRED_SIZE))
										.addContainerGap()));
		jPanel1Layout
				.setVerticalGroup(jPanel1Layout
						.createParallelGroup(
								javax.swing.GroupLayout.Alignment.LEADING)
						.addGroup(
								javax.swing.GroupLayout.Alignment.TRAILING,
								jPanel1Layout
										.createSequentialGroup()
										.addGap(34, 34, 34)
										.addComponent(
												jLabel1,
												javax.swing.GroupLayout.PREFERRED_SIZE,
												42,
												javax.swing.GroupLayout.PREFERRED_SIZE)
										.addPreferredGap(
												javax.swing.LayoutStyle.ComponentPlacement.RELATED,
												38, Short.MAX_VALUE)
										.addGroup(
												jPanel1Layout
														.createParallelGroup(
																javax.swing.GroupLayout.Alignment.BASELINE)
														.addComponent(
																jCheckBox2)
														.addComponent(
																jCheckBox1))
										.addGap(35, 35, 35)
										.addGroup(
												jPanel1Layout
														.createParallelGroup(
																javax.swing.GroupLayout.Alignment.BASELINE)
														.addComponent(jButton7)
														.addComponent(jButton8)
														.addComponent(jButton9))
										.addContainerGap()));

		jTabbedPane1.addTab("\u7b2c\u4e09\u9898", jPanel1);

		javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
		this.setLayout(layout);
		layout.setHorizontalGroup(layout.createParallelGroup(
				javax.swing.GroupLayout.Alignment.LEADING).addGroup(
				layout.createSequentialGroup().addGap(53, 53, 53).addComponent(
						jTabbedPane1, javax.swing.GroupLayout.PREFERRED_SIZE,
						624, javax.swing.GroupLayout.PREFERRED_SIZE)
						.addContainerGap(50, Short.MAX_VALUE)));
		layout.setVerticalGroup(layout.createParallelGroup(
				javax.swing.GroupLayout.Alignment.LEADING).addGroup(
				layout.createSequentialGroup().addContainerGap().addComponent(
						jTabbedPane1, javax.swing.GroupLayout.PREFERRED_SIZE,
						270, javax.swing.GroupLayout.PREFERRED_SIZE)
						.addContainerGap(43, Short.MAX_VALUE)));
	}// </editor-fold>
	//GEN-END:initComponents

	private void jButton9ActionPerformed(java.awt.event.ActionEvent evt) {
		exam.jTabbedPane1.remove(exam.jPanel4);
		exam.jTabbedPane1.add(new textMultiselect("4", null, null));
	}

	private void jButton8ActionPerformed(java.awt.event.ActionEvent evt) {
		jButton8.setText("�ѱ���");
		exam.jProgressBar1.setValue(75);
		jButton9.setEnabled(true);
	}

	private void jButton7ActionPerformed(java.awt.event.ActionEvent evt) {
		// TODO add your handling code here:
	}

	//GEN-BEGIN:variables
	// Variables declaration - do not modify
	private javax.swing.JButton jButton7;
	private javax.swing.JButton jButton8;
	private javax.swing.JButton jButton9;
	private javax.swing.JCheckBox jCheckBox1;
	static javax.swing.JCheckBox jCheckBox2;
	private javax.swing.JLabel jLabel1;
	private javax.swing.JPanel jPanel1;
	private javax.swing.JTabbedPane jTabbedPane1;
	// End of variables declaration//GEN-END:variables

}