/*
 * checkResult.java
 *
 * Created on __DATE__, __TIME__
 */

package studentView;

import java.io.IOException;
import java.net.UnknownHostException;
import java.util.ArrayList;

import javax.swing.table.DefaultTableModel;

import model.Exam_results;

/**
 *
 * @author  __USER__
 */
public class checkResult extends javax.swing.JFrame {

	/** Creates new form checkResult */
	public checkResult() {
		initComponents();
		try {
			loadTable();
		} catch (UnknownHostException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		this.setLocationRelativeTo(null);
	}

	void loadTable() throws UnknownHostException, IOException,
			ClassNotFoundException {
		Exam_results ers = new Exam_results();
		ArrayList<Exam_results> exr = ers.viewData3();
		Object title[] = { "ѧ������", "ѧ������", "ѧ���ɼ�","ѧ������" };
		Object detail[][] = new Object[exr.size()][4];
		for (int i = 0; i < exr.size(); i++) {
			detail[i][0] = exr.get(i).getId();
			detail[i][1] = exr.get(i).getName();
			detail[i][2] = exr.get(i).getResults();
			detail[i][3] = exr.get(i).getGradepoint();
		}
		this.jTable1.setModel(new DefaultTableModel(detail, title));

	}

	//GEN-BEGIN:initComponents
	// <editor-fold defaultstate="collapsed" desc="Generated Code">
	private void initComponents() {

		jPanel1 = new javax.swing.JPanel();
		jLabel1 = new javax.swing.JLabel();
		jScrollPane1 = new javax.swing.JScrollPane();
		jTable1 = new javax.swing.JTable();
		jButton2 = new javax.swing.JButton();

		setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

		jPanel1.setBackground(new java.awt.Color(102, 153, 255));
		jPanel1.setForeground(new java.awt.Color(153, 153, 153));

		jLabel1.setFont(new java.awt.Font("����", 1, 45));
		jLabel1.setForeground(new java.awt.Color(255, 255, 255));
		jLabel1.setText("\u67e5\u770b\u6210\u7ee9");

		jTable1.setModel(new javax.swing.table.DefaultTableModel(
				new Object[][] { { null, null, null, null },
						{ null, null, null, null }, { null, null, null, null },
						{ null, null, null, null } }, new String[] { "Title 1",
						"Title 2", "Title 3", "Title 4" }));
		jScrollPane1.setViewportView(jTable1);

		jButton2.setBackground(new java.awt.Color(153, 153, 153));
		jButton2.setFont(new java.awt.Font("Microsoft YaHei UI", 0, 20));
		jButton2.setForeground(new java.awt.Color(255, 255, 255));
		jButton2.setText("\u8fd4\u56de");
		jButton2.setBorderPainted(false);
		jButton2.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				jButton2ActionPerformed(evt);
			}
		});

		javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(
				jPanel1);
		jPanel1.setLayout(jPanel1Layout);
		jPanel1Layout.setHorizontalGroup(jPanel1Layout.createParallelGroup(
				javax.swing.GroupLayout.Alignment.LEADING).addGroup(
				jPanel1Layout.createSequentialGroup().addGap(120, 120, 120)
						.addComponent(jScrollPane1,
								javax.swing.GroupLayout.PREFERRED_SIZE,
								javax.swing.GroupLayout.DEFAULT_SIZE,
								javax.swing.GroupLayout.PREFERRED_SIZE)
						.addContainerGap(133, Short.MAX_VALUE)).addGroup(
				javax.swing.GroupLayout.Alignment.TRAILING,
				jPanel1Layout.createSequentialGroup().addContainerGap(260,
						Short.MAX_VALUE).addComponent(jLabel1).addGap(257, 257,
						257)).addGroup(
				jPanel1Layout.createSequentialGroup().addGap(280, 280, 280)
						.addComponent(jButton2,
								javax.swing.GroupLayout.PREFERRED_SIZE, 125,
								javax.swing.GroupLayout.PREFERRED_SIZE)
						.addContainerGap(300, Short.MAX_VALUE)));
		jPanel1Layout.setVerticalGroup(jPanel1Layout.createParallelGroup(
				javax.swing.GroupLayout.Alignment.LEADING).addGroup(
				jPanel1Layout.createSequentialGroup().addGap(47, 47, 47)
						.addComponent(jLabel1).addGap(36, 36, 36).addComponent(
								jScrollPane1,
								javax.swing.GroupLayout.PREFERRED_SIZE, 217,
								javax.swing.GroupLayout.PREFERRED_SIZE).addGap(
								62, 62, 62).addComponent(jButton2,
								javax.swing.GroupLayout.PREFERRED_SIZE, 40,
								javax.swing.GroupLayout.PREFERRED_SIZE)
						.addContainerGap(86, Short.MAX_VALUE)));

		javax.swing.GroupLayout layout = new javax.swing.GroupLayout(
				getContentPane());
		getContentPane().setLayout(layout);
		layout.setHorizontalGroup(layout.createParallelGroup(
				javax.swing.GroupLayout.Alignment.LEADING).addComponent(
				jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE,
				javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE));
		layout.setVerticalGroup(layout.createParallelGroup(
				javax.swing.GroupLayout.Alignment.LEADING).addComponent(
				jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE,
				javax.swing.GroupLayout.DEFAULT_SIZE,
				javax.swing.GroupLayout.PREFERRED_SIZE));

		pack();
	}// </editor-fold>
	//GEN-END:initComponents

	private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {
		studentMain frame5 = new studentMain();
		frame5.setVisible(true);
		dispose();
	}

	/**
	 * @param args the command line arguments
	 */
	public static void main(String args[]) {
		java.awt.EventQueue.invokeLater(new Runnable() {
			public void run() {
				new checkResult().setVisible(true);
			}
		});
	}

	//GEN-BEGIN:variables
	// Variables declaration - do not modify
	private javax.swing.JButton jButton2;
	private javax.swing.JLabel jLabel1;
	private javax.swing.JPanel jPanel1;
	private javax.swing.JScrollPane jScrollPane1;
	private javax.swing.JTable jTable1;
	// End of variables declaration//GEN-END:variables

}