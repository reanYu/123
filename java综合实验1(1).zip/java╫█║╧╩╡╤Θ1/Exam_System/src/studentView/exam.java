/*
 * exam.java
 *
 * Created on __DATE__, __TIME__
 */

package studentView;

import java.awt.Window;

import javax.swing.JFrame;
import javax.swing.JOptionPane;

/**
 *
 * @author  __USER__
 */
public class exam extends javax.swing.JFrame implements Runnable {

	/** Creates new form exam */
	public exam() {
		initComponents();
		this.setLocationRelativeTo(null);
	}

	//GEN-BEGIN:initComponents
	// <editor-fold defaultstate="collapsed" desc="Generated Code">
	private void initComponents() {

		jPanel1 = new javax.swing.JPanel();
		jLabel1 = new javax.swing.JLabel();
		jLabel2 = new javax.swing.JLabel();
		jLabel3 = new javax.swing.JLabel();
		jLabel4 = new javax.swing.JLabel();
		jPanel2 = new javax.swing.JPanel();
		jButton1 = new javax.swing.JButton();
		jButton2 = new javax.swing.JButton();
		jTabbedPane1 = new javax.swing.JTabbedPane();
		jPanel4 = new javax.swing.JPanel();
		jButton4 = new javax.swing.JButton();
		jLabel5 = new javax.swing.JLabel();
		jPanel3 = new javax.swing.JPanel();
		jProgressBar1 = new javax.swing.JProgressBar();

		setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

		jPanel1.setBackground(new java.awt.Color(255, 255, 255));

		jLabel1.setFont(new java.awt.Font("Microsoft YaHei UI", 0, 30));
		jLabel1.setText("\u79d1\u76ee");

		jLabel2.setFont(new java.awt.Font("Microsoft YaHei UI", 0, 19));
		jLabel2.setText("\u5269\u4f59\u65f6\u95f4\u4e3a\uff1a");

		jLabel3.setFont(new java.awt.Font("Microsoft YaHei UI", 0, 21));
		jLabel3.setText("30");

		jLabel4.setFont(new java.awt.Font("����", 0, 19));
		jLabel4.setText("\u79d2");

		javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(
				jPanel1);
		jPanel1.setLayout(jPanel1Layout);
		jPanel1Layout
				.setHorizontalGroup(jPanel1Layout
						.createParallelGroup(
								javax.swing.GroupLayout.Alignment.LEADING)
						.addGroup(
								jPanel1Layout
										.createSequentialGroup()
										.addGap(435, 435, 435)
										.addComponent(jLabel1)
										.addGap(237, 237, 237)
										.addComponent(jLabel2)
										.addPreferredGap(
												javax.swing.LayoutStyle.ComponentPlacement.RELATED)
										.addComponent(
												jLabel3,
												javax.swing.GroupLayout.PREFERRED_SIZE,
												27,
												javax.swing.GroupLayout.PREFERRED_SIZE)
										.addPreferredGap(
												javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
										.addComponent(jLabel4).addGap(67, 67,
												67)));
		jPanel1Layout
				.setVerticalGroup(jPanel1Layout
						.createParallelGroup(
								javax.swing.GroupLayout.Alignment.LEADING)
						.addGroup(
								jPanel1Layout
										.createSequentialGroup()
										.addContainerGap()
										.addGroup(
												jPanel1Layout
														.createParallelGroup(
																javax.swing.GroupLayout.Alignment.LEADING)
														.addComponent(jLabel1)
														.addGroup(
																jPanel1Layout
																		.createParallelGroup(
																				javax.swing.GroupLayout.Alignment.BASELINE)
																		.addComponent(
																				jLabel2,
																				javax.swing.GroupLayout.PREFERRED_SIZE,
																				72,
																				javax.swing.GroupLayout.PREFERRED_SIZE)
																		.addComponent(
																				jLabel4,
																				javax.swing.GroupLayout.PREFERRED_SIZE,
																				31,
																				javax.swing.GroupLayout.PREFERRED_SIZE)
																		.addComponent(
																				jLabel3,
																				javax.swing.GroupLayout.PREFERRED_SIZE,
																				58,
																				javax.swing.GroupLayout.PREFERRED_SIZE)))
										.addContainerGap()));

		jPanel2.setBackground(new java.awt.Color(255, 255, 255));

		jButton1.setBackground(new java.awt.Color(102, 153, 255));
		jButton1.setFont(new java.awt.Font("Microsoft YaHei UI", 0, 21));
		jButton1.setForeground(new java.awt.Color(255, 255, 255));
		jButton1.setText("\u63d0\u4ea4\u7b54\u5377");
		jButton1.setBorderPainted(false);
		jButton1.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				jButton1ActionPerformed(evt);
			}
		});

		jButton2.setBackground(new java.awt.Color(102, 153, 255));
		jButton2.setFont(new java.awt.Font("Microsoft YaHei UI", 0, 21));
		jButton2.setForeground(new java.awt.Color(255, 255, 255));
		jButton2.setText("\u9000\u51fa\u8003\u8bd5");
		jButton2.setBorderPainted(false);
		jButton2.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				jButton2ActionPerformed(evt);
			}
		});

		jTabbedPane1.setFont(new java.awt.Font("Microsoft YaHei UI", 0, 21));

		jPanel4.setBackground(new java.awt.Color(255, 255, 255));

		jButton4.setBackground(new java.awt.Color(102, 153, 255));
		jButton4.setFont(new java.awt.Font("Microsoft YaHei UI", 0, 21));
		jButton4.setForeground(new java.awt.Color(255, 255, 255));
		jButton4.setText("\u5f00\u59cb\u7b54\u9898");
		jButton4.setBorderPainted(false);
		jButton4.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				jButton4ActionPerformed(evt);
			}
		});

		javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(
				jPanel4);
		jPanel4.setLayout(jPanel4Layout);
		jPanel4Layout.setHorizontalGroup(jPanel4Layout.createParallelGroup(
				javax.swing.GroupLayout.Alignment.LEADING).addGap(0, 861,
				Short.MAX_VALUE).addGroup(
				jPanel4Layout.createParallelGroup(
						javax.swing.GroupLayout.Alignment.LEADING).addGroup(
						jPanel4Layout.createSequentialGroup().addGap(372, 372,
								372).addComponent(jButton4).addContainerGap(
								372, Short.MAX_VALUE))));
		jPanel4Layout.setVerticalGroup(jPanel4Layout.createParallelGroup(
				javax.swing.GroupLayout.Alignment.LEADING).addGap(0, 345,
				Short.MAX_VALUE).addGroup(
				jPanel4Layout.createParallelGroup(
						javax.swing.GroupLayout.Alignment.LEADING).addGroup(
						jPanel4Layout.createSequentialGroup().addGap(146, 146,
								146).addComponent(jButton4).addContainerGap(
								147, Short.MAX_VALUE))));

		jTabbedPane1.addTab("\u8003\u8bd5\u9898\u76ee", jPanel4);

		jLabel5.setFont(new java.awt.Font("Microsoft JhengHei UI", 0, 21));
		jLabel5.setForeground(new java.awt.Color(255, 0, 0));

		javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(
				jPanel2);
		jPanel2.setLayout(jPanel2Layout);
		jPanel2Layout
				.setHorizontalGroup(jPanel2Layout
						.createParallelGroup(
								javax.swing.GroupLayout.Alignment.LEADING)
						.addGroup(
								javax.swing.GroupLayout.Alignment.TRAILING,
								jPanel2Layout
										.createSequentialGroup()
										.addGap(92, 92, 92)
										.addComponent(jButton2)
										.addPreferredGap(
												javax.swing.LayoutStyle.ComponentPlacement.RELATED,
												570, Short.MAX_VALUE)
										.addComponent(jButton1).addGap(82, 82,
												82))
						.addGroup(
								jPanel2Layout.createSequentialGroup().addGap(
										54, 54, 54).addComponent(jTabbedPane1,
										javax.swing.GroupLayout.PREFERRED_SIZE,
										866,
										javax.swing.GroupLayout.PREFERRED_SIZE)
										.addContainerGap(58, Short.MAX_VALUE))
						.addGroup(
								javax.swing.GroupLayout.Alignment.TRAILING,
								jPanel2Layout
										.createSequentialGroup()
										.addContainerGap(590, Short.MAX_VALUE)
										.addComponent(
												jLabel5,
												javax.swing.GroupLayout.PREFERRED_SIZE,
												366,
												javax.swing.GroupLayout.PREFERRED_SIZE)
										.addGap(22, 22, 22)));
		jPanel2Layout
				.setVerticalGroup(jPanel2Layout
						.createParallelGroup(
								javax.swing.GroupLayout.Alignment.LEADING)
						.addGroup(
								javax.swing.GroupLayout.Alignment.TRAILING,
								jPanel2Layout
										.createSequentialGroup()
										.addContainerGap()
										.addComponent(
												jLabel5,
												javax.swing.GroupLayout.PREFERRED_SIZE,
												30,
												javax.swing.GroupLayout.PREFERRED_SIZE)
										.addPreferredGap(
												javax.swing.LayoutStyle.ComponentPlacement.RELATED)
										.addComponent(
												jTabbedPane1,
												javax.swing.GroupLayout.DEFAULT_SIZE,
												387, Short.MAX_VALUE)
										.addPreferredGap(
												javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
										.addGroup(
												jPanel2Layout
														.createParallelGroup(
																javax.swing.GroupLayout.Alignment.BASELINE)
														.addComponent(jButton1)
														.addComponent(jButton2))
										.addGap(40, 40, 40)));

		jPanel3.setBackground(new java.awt.Color(255, 255, 255));

		jProgressBar1.setForeground(new java.awt.Color(6, 176, 37));

		javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(
				jPanel3);
		jPanel3.setLayout(jPanel3Layout);
		jPanel3Layout.setHorizontalGroup(jPanel3Layout.createParallelGroup(
				javax.swing.GroupLayout.Alignment.LEADING).addGroup(
				jPanel3Layout.createSequentialGroup().addGap(30, 30, 30)
						.addComponent(jProgressBar1,
								javax.swing.GroupLayout.PREFERRED_SIZE, 922,
								javax.swing.GroupLayout.PREFERRED_SIZE)
						.addContainerGap(26, Short.MAX_VALUE)));
		jPanel3Layout.setVerticalGroup(jPanel3Layout.createParallelGroup(
				javax.swing.GroupLayout.Alignment.LEADING).addGroup(
				javax.swing.GroupLayout.Alignment.TRAILING,
				jPanel3Layout.createSequentialGroup().addContainerGap(23,
						Short.MAX_VALUE).addComponent(jProgressBar1,
						javax.swing.GroupLayout.PREFERRED_SIZE, 26,
						javax.swing.GroupLayout.PREFERRED_SIZE).addGap(22, 22,
						22)));

		javax.swing.GroupLayout layout = new javax.swing.GroupLayout(
				getContentPane());
		getContentPane().setLayout(layout);
		layout.setHorizontalGroup(layout.createParallelGroup(
				javax.swing.GroupLayout.Alignment.LEADING).addComponent(
				jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 978,
				Short.MAX_VALUE).addComponent(jPanel2,
				javax.swing.GroupLayout.DEFAULT_SIZE,
				javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
				.addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE,
						javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE));
		layout
				.setVerticalGroup(layout
						.createParallelGroup(
								javax.swing.GroupLayout.Alignment.LEADING)
						.addGroup(
								layout
										.createSequentialGroup()
										.addComponent(
												jPanel1,
												javax.swing.GroupLayout.PREFERRED_SIZE,
												javax.swing.GroupLayout.DEFAULT_SIZE,
												javax.swing.GroupLayout.PREFERRED_SIZE)
										.addPreferredGap(
												javax.swing.LayoutStyle.ComponentPlacement.RELATED)
										.addComponent(
												jPanel2,
												javax.swing.GroupLayout.DEFAULT_SIZE,
												javax.swing.GroupLayout.DEFAULT_SIZE,
												Short.MAX_VALUE)
										.addPreferredGap(
												javax.swing.LayoutStyle.ComponentPlacement.RELATED)
										.addComponent(
												jPanel3,
												javax.swing.GroupLayout.PREFERRED_SIZE,
												javax.swing.GroupLayout.DEFAULT_SIZE,
												javax.swing.GroupLayout.PREFERRED_SIZE)));

		pack();
	}// </editor-fold>
	//GEN-END:initComponents

	private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {
		this.jTabbedPane1.remove(this.jPanel4);
		this.jTabbedPane1.add(new textChoose("1", null, null));
		Thread t = new Thread(this);
		t.start();
	}

	private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {

		int score = 0;
		if (textChoose.jRadioButton3.isSelected()
				&& textChoose.jRadioButton5.isSelected()) {
			score = score + 25;
		}
		if (textJudge.jCheckBox2.isSelected()) {
			score = score + 25;
		}
		if (textMultiselect.jCheckBox1.isSelected()) {
			score = score + 25;
		}

		JOptionPane.showMessageDialog(this, "�ύ�ɹ�,���ķ���Ϊ��" + score);
	}

	private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {
		JOptionPane.showMessageDialog(this, "���Խ������˳�����");
		studentMain frame5 = new studentMain();
		frame5.setVisible(true);
		dispose();
	}

	/**
	 * @param args the command line arguments
	 */
	public static void main(String args[]) {
		java.awt.EventQueue.invokeLater(new Runnable() {
			public void run() {
				new exam().setVisible(true);
			}
		});
	}

	//GEN-BEGIN:variables
	// Variables declaration - do not modify
	private javax.swing.JButton jButton1;
	private javax.swing.JButton jButton2;
	private javax.swing.JButton jButton4;
	private javax.swing.JLabel jLabel1;
	private javax.swing.JLabel jLabel2;
	private javax.swing.JLabel jLabel3;
	private javax.swing.JLabel jLabel4;
	private javax.swing.JLabel jLabel5;
	private javax.swing.JPanel jPanel1;
	private javax.swing.JPanel jPanel2;
	private javax.swing.JPanel jPanel3;
	static javax.swing.JPanel jPanel4;
	static javax.swing.JProgressBar jProgressBar1;
	static javax.swing.JTabbedPane jTabbedPane1;

	// End of variables declaration//GEN-END:variables
	@Override
	public void run() {
		// TODO Auto-generated method stub
		for (int i = 30; i >= 0; i--) {
			try {
				this.jLabel3.setText(i + "");
				Thread.sleep(1000);
				if (i == 15) {
					this.jLabel5.setText("�뿼�Խ�������15�룡����");
				} else if (i == 0) {
					int score = 0;
					if (textChoose.jRadioButton3.isSelected()
							&& textChoose.jRadioButton5.isSelected()) {
						score = score + 25;
					}
					if (textJudge.jCheckBox2.isSelected()) {
						score = score + 25;
					}
					if (textMultiselect.jCheckBox1.isSelected()) {
						score = score + 25;
					}
					JOptionPane.showMessageDialog(this, "���Խ���,���ķ���Ϊ��" + score);
					studentMain frame5 = new studentMain();
					frame5.setVisible(true);
					dispose();
				}
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}

	}
}