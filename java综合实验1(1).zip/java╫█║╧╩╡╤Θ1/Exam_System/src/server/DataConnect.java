package server;

import java.sql.*;
import javax.sql.*;

public class DataConnect {

	private static Statement stat;
	private static void init() throws ClassNotFoundException, SQLException {
		// TODO Auto-generated method stub
		Class.forName("com.mysql.jdbc.Driver");
		System.out.println("�������ݿ�");
		Connection conn = DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/exam_system","root","123123");
        stat = conn.createStatement();
	}
	public static Statement getStatment() throws ClassNotFoundException, SQLException{
		if(stat==null)
			init();
		return stat;
		
	}
}
