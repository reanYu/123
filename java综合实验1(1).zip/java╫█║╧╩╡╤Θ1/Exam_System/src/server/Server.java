package server;

import java.net.*;
import java.sql.*;
import java.util.ArrayList;
import java.io.*;

import model.Admin_Imessage;
import model.Exam_results;
import model.Student_Imessage;
import model.Teacher_Imessage;
import model.Text_choose;
import model.Text_fill;
import model.Text_judge;
import model.Text_multiselect;
import model.Text_paper;



public class Server {
	ObjectOutputStream oos;
	ObjectInputStream ois;
	Socket s;
	
	final int LOGIN = 1001;
	final int REGISTER = 1002;
	final int MODIFY= 1003;
	final int LOGINN= 1004;
	final int REGISTERR= 1005;
	final int LOGINNN= 1006;
	final int REGISTERRR= 1007;
	final int MODIFYY = 1009;
	final int INSERT = 1012;
	final int INSERTT = 1013;
	final int INSERTTT = 1014;
	final int INSERTTTT = 1015;
	final int MODIFYYY = 1016;
	final int MODIFYYYY = 1017;
	final int MODIFYYYYY = 1018;
	final int MODIFYYYYYY = 1019;
	final int REGISTERRRR = 1020;
	final int INSERTTTTT = 1021;
	public Server() throws IOException, ClassNotFoundException, SQLException{
		ServerSocket ss = new ServerSocket(23456); 
		while(true){
			s = ss.accept();
			ois = new ObjectInputStream(s.getInputStream());
			oos = new ObjectOutputStream(s.getOutputStream());
			int command = ois.readInt();
			if(command == LOGIN){
				login();
			}
			if(command == REGISTER){
				register();
			}
			if(command == MODIFY){
				modify();
			}
			
			if(command == LOGINN){
				login2();
			}
			if(command == REGISTERR){
				register2();
			}
			if(command == LOGINNN){
				login3();
			}
			if(command == REGISTERRR){
				register3();
			}
			if(command == MODIFYY){
				modify2();
			}
			if(command == INSERT){
				insert1();
			}
			if(command == INSERTT){
				insert2();
			}
			if(command == INSERTTT){
				insert3();
			}
			if(command == INSERTTTT){
				insert4();
			}
			if(command == MODIFYYY){
				modify3();
			}
			if(command == MODIFYYYY){
				modify4();
			}
			if(command == MODIFYYYYY){
				modify5();
			}
			if(command == MODIFYYYYYY){
				modify6();
			}
			if(command == REGISTERRRR){
				register4();
			}
			if(command == INSERTTTTT){
				insert5();
			}
			
			if(command == 1000){
				String sql = "select * from student_imessage";
				ResultSet rs = DataConnect.getStatment().executeQuery(sql);
				ArrayList<Student_Imessage> ssi = new ArrayList<Student_Imessage>();
				while(rs.next()){
					ssi.add(new Student_Imessage(rs.getString(1),rs.getString(2),rs.getString(3),rs.getString(4)));
					
				}
				oos.writeObject(ssi);
				oos.flush();
			}
			if(command == 1011){
				String sql = "select * from teacher_imessage";
				ResultSet rs = DataConnect.getStatment().executeQuery(sql);
				ArrayList<Teacher_Imessage> tti = new ArrayList<Teacher_Imessage>();
				while(rs.next()){
					tti.add(new Teacher_Imessage(rs.getString(1),rs.getString(2),rs.getString(3),rs.getString(4)));
					
				}
				oos.writeObject(tti);
				oos.flush();
			}
			if(command == 1023){
				String sql = "select * from text_paper";
				ResultSet rs = DataConnect.getStatment().executeQuery(sql);
				ArrayList<Text_paper> ttp = new ArrayList<Text_paper>();
				while(rs.next()){
					ttp.add(new Text_paper(rs.getString(1),rs.getString(2),rs.getString(3)));
					
				}
				oos.writeObject(ttp);
				oos.flush();
			}
			
			if(command == 1022){
				String sql = "select * from exam_results";
				ResultSet rs = DataConnect.getStatment().executeQuery(sql);
				ArrayList<Exam_results> ers = new ArrayList<Exam_results>();
				while(rs.next()){
					ers.add(new Exam_results(rs.getString(1),rs.getString(2),rs.getString(3),rs.getString(4)));
					
				}
				oos.writeObject(ers);
				oos.flush();
			}
		}
		
		
	};
	
	
	
	public void login() throws IOException, ClassNotFoundException, SQLException{
		String id = ois.readUTF();
		String pw = ois.readUTF();
		Student_Imessage si= null;
		String sql = "select * from student_imessage where id='"+id+"' and pw='"+pw+"'";
	    ResultSet rs = DataConnect.getStatment().executeQuery(sql);
		if(rs.next())
		si = new Student_Imessage(rs.getString(1),rs.getString(2),rs.getString(3),rs.getString(4));
		oos.writeObject(si);
		oos.flush();
	}
	
	public void register() throws IOException{
		String name = ois.readUTF();
		String id = ois.readUTF();
		String  pw= ois.readUTF();
		String headPhoto = ois.readUTF();
		Student_Imessage si = null;
		String sql = "insert into student_imessage values('"+name+"','"+id+"','"+pw+"','"+headPhoto+"')";
		try {
			DataConnect.getStatment().executeUpdate(sql);
			oos.writeObject(new Student_Imessage(name,id,pw,headPhoto));
			oos.flush();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
		    oos.writeObject(null);
		    oos.flush();
		    e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		}
		
		public void modify() throws IOException{
			String name = ois.readUTF();
			String id = ois.readUTF();
			String  pw= ois.readUTF();
			String headPhoto = ois.readUTF();
			Student_Imessage si = null;
			String sql = "update student_imessage set name='"+name+"',pw='"+pw+"'where id = '"+id+"'"; 
			try {
				DataConnect.getStatment().executeUpdate(sql);
				oos.writeObject(new Student_Imessage(name,id,pw,headPhoto));
				oos.flush();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
			    oos.writeObject(null);
			    oos.flush();
			    e.printStackTrace();
			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			}
			
		public void modify2() throws IOException{
			String name = ois.readUTF();
			String id = ois.readUTF();
			String  pw= ois.readUTF();
			String headPhoto = ois.readUTF();
			Teacher_Imessage ti = null;
			String sql = "update teacher_imessage set name='"+name+"',pw='"+pw+"'where id = '"+id+"'"; 
			try {
				DataConnect.getStatment().executeUpdate(sql);
				oos.writeObject(new Teacher_Imessage(name,id,pw,headPhoto));
				oos.flush();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
			    oos.writeObject(null);
			    oos.flush();
			    e.printStackTrace();
			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			}
		
		
			public void login2() throws IOException, ClassNotFoundException, SQLException{
				String id = ois.readUTF();
				String pw = ois.readUTF();
				Teacher_Imessage ti= null;
				String sql = "select * from teacher_imessage where id='"+id+"' and pw='"+pw+"'";
			    ResultSet rs = DataConnect.getStatment().executeQuery(sql);
				if(rs.next())
				ti = new Teacher_Imessage(rs.getString(1),rs.getString(2),rs.getString(3),rs.getString(4));
				oos.writeObject(ti);
				oos.flush();
			}
			
			public void register2() throws IOException{
				String name = ois.readUTF();
				String id = ois.readUTF();
				String  pw= ois.readUTF();
				String headPhoto = ois.readUTF();
				Teacher_Imessage ti = null;
				String sql = "insert into teacher_imessage values('"+name+"','"+id+"','"+pw+"','"+headPhoto+"')";
				try {
					DataConnect.getStatment().executeUpdate(sql);
					oos.writeObject(new Teacher_Imessage(name,id,pw,headPhoto));
					oos.flush();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
				    oos.writeObject(null);
				    oos.flush();
				    e.printStackTrace();
				} catch (ClassNotFoundException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				}
				
				public void login3() throws IOException, ClassNotFoundException, SQLException{
					String id = ois.readUTF();
					String pw = ois.readUTF();
					Admin_Imessage ai= null;
					String sql = "select * from admin_imessage where id='"+id+"' and pw='"+pw+"'";
				    ResultSet rs = DataConnect.getStatment().executeQuery(sql);
					if(rs.next())
					ai = new Admin_Imessage(rs.getString(1),rs.getString(2),rs.getString(3),rs.getString(4));
					oos.writeObject(ai);
					oos.flush();
				}
				
				public void register3() throws IOException{
					String name = ois.readUTF();
					String id = ois.readUTF();
					String  pw= ois.readUTF();
					String headPhoto = ois.readUTF();
					Admin_Imessage ai = null;
					String sql = "insert into admin_imessage values('"+name+"','"+id+"','"+pw+"','"+headPhoto+"')";
					try {
						DataConnect.getStatment().executeUpdate(sql);
						oos.writeObject(new Admin_Imessage(name,id,pw,headPhoto));
						oos.flush();
					} catch (SQLException e) {
						// TODO Auto-generated catch block
					    oos.writeObject(null);
					    oos.flush();
					    e.printStackTrace();
					} catch (ClassNotFoundException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
		
	}
				public void insert1() throws IOException{
					String id = ois.readUTF();
					String topic = ois.readUTF();
					String  option_A= ois.readUTF();
					String option_B = ois.readUTF();
					String option_C = ois.readUTF();
					String option_D = ois.readUTF();
					String option_E = ois.readUTF();
					String  answer1= ois.readUTF();
					String  answer2= ois.readUTF();
					Text_multiselect tmi = null;
					String sql = "insert into text_multiselect values('"+id+"','"+topic+"','"+option_A+"','"+option_B+"','"+option_C+"','"+option_D+"','"+option_E+"','"+answer1+"','"+answer2+"')";
					try {
						DataConnect.getStatment().executeUpdate(sql);
						oos.writeObject(new Text_multiselect(id,topic,option_A,option_B,option_C,option_D,option_E,answer1,answer2));
						oos.flush();
					} catch (SQLException e) {
						// TODO Auto-generated catch block
					    oos.writeObject(null);
					    oos.flush();
					    e.printStackTrace();
					} catch (ClassNotFoundException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					}
				
				public void insert2() throws IOException{
					String id = ois.readUTF();
					String topic = ois.readUTF();
					String  option_A= ois.readUTF();
					String option_B = ois.readUTF();
					String option_C = ois.readUTF();
					String option_D = ois.readUTF();
					String  answer= ois.readUTF();
					Text_choose tc = null;
					String sql = "insert into text_choose values('"+id+"','"+topic+"','"+option_A+"','"+option_B+"','"+option_C+"','"+option_D+"','"+answer+"')";
					try {
						DataConnect.getStatment().executeUpdate(sql);
						oos.writeObject(new Text_choose(id,topic,option_A,option_B,option_C,option_D,answer));
						oos.flush();
					} catch (SQLException e) {
						// TODO Auto-generated catch block
					    oos.writeObject(null);
					    oos.flush();
					    e.printStackTrace();
					} catch (ClassNotFoundException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					}
				
				public void insert3() throws IOException{
					String id = ois.readUTF();
					String topic = ois.readUTF();
					String  answer= ois.readUTF();
					Text_judge tj = null;
					String sql = "insert into text_judge values('"+id+"','"+topic+"','"+answer+"')";
					try {
						DataConnect.getStatment().executeUpdate(sql);
						oos.writeObject(new Text_judge(id,topic,answer));
						oos.flush();
					} catch (SQLException e) {
						// TODO Auto-generated catch block
					    oos.writeObject(null);
					    oos.flush();
					    e.printStackTrace();
					} catch (ClassNotFoundException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					}
				
				public void insert4() throws IOException{
					String id = ois.readUTF();
					String topic = ois.readUTF();
					String  answer= ois.readUTF();
					Text_fill tf = null;
					String sql = "insert into text_fill values('"+id+"','"+topic+"','"+answer+"')";
					try {
						DataConnect.getStatment().executeUpdate(sql);
						oos.writeObject(new Text_fill(id,topic,answer));
						oos.flush();
					} catch (SQLException e) {
						// TODO Auto-generated catch block
					    oos.writeObject(null);
					    oos.flush();
					    e.printStackTrace();
					} catch (ClassNotFoundException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					}
				public void modify3() throws IOException{
					String id = ois.readUTF();
					String topic = ois.readUTF();
					String  option_A= ois.readUTF();
					String option_B = ois.readUTF();
					String option_C = ois.readUTF();
					String option_D = ois.readUTF();
					String option_E = ois.readUTF();
					String  answer1= ois.readUTF();
					String  answer2= ois.readUTF();
					Text_multiselect tm = null;
					String sql = "update text_multiselect set topic='"+topic+"',option_A='"+option_A+"',option_B='"+option_B+"',option_C='"+option_C+"',option_D='"+option_D+"',option_E='"+option_E+"',answer1='"+answer1+"',answer2='"+answer2+"'where id = '"+id+"'"; 
					try {
						DataConnect.getStatment().executeUpdate(sql);
						oos.writeObject(new Text_multiselect(id,topic,option_A,option_B,option_C,option_D,option_E,answer1,answer2));
						oos.flush();
					} catch (SQLException e) {
						// TODO Auto-generated catch block
					    oos.writeObject(null);
					    oos.flush();
					    e.printStackTrace();
					} catch (ClassNotFoundException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					}
				public void modify4() throws IOException{
					String id = ois.readUTF();
					String topic = ois.readUTF();
					String  option_A= ois.readUTF();
					String option_B = ois.readUTF();
					String option_C = ois.readUTF();
					String option_D = ois.readUTF();
					String  answer= ois.readUTF();
					Text_choose tc = null;
					String sql = "update text_choose set topic='"+topic+"',option_A='"+option_A+"',option_B='"+option_B+"',option_C='"+option_C+"',option_D='"+option_D+"',answer='"+answer+"'where id = '"+id+"'"; 
					try {
						DataConnect.getStatment().executeUpdate(sql);
						oos.writeObject(new Text_choose(id,topic,option_A,option_B,option_C,option_D,answer));
						oos.flush();
					} catch (SQLException e) {
						// TODO Auto-generated catch block
					    oos.writeObject(null);
					    oos.flush();
					    e.printStackTrace();
					} catch (ClassNotFoundException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					}
				public void modify5() throws IOException{
					String id = ois.readUTF();
					String topic = ois.readUTF();
					String  answer= ois.readUTF();
					Text_judge tj = null;
					String sql = "update text_judge set topic='"+topic+"',answer='"+answer+"'where id = '"+id+"'"; 
					try {
						DataConnect.getStatment().executeUpdate(sql);
						oos.writeObject(new Text_judge(id,topic,answer));
						oos.flush();
					} catch (SQLException e) {
						// TODO Auto-generated catch block
					    oos.writeObject(null);
					    oos.flush();
					    e.printStackTrace();
					} catch (ClassNotFoundException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					}
				public void modify6() throws IOException{
					String id = ois.readUTF();
					String topic = ois.readUTF();
					String  answer= ois.readUTF();
					Text_fill tf = null;
					String sql = "update text_fill set topic='"+topic+"',answer='"+answer+"'where id = '"+id+"'"; 
					try {
						DataConnect.getStatment().executeUpdate(sql);
						oos.writeObject(new Text_fill(id,topic,answer));
						oos.flush();
					} catch (SQLException e) {
						// TODO Auto-generated catch block
					    oos.writeObject(null);
					    oos.flush();
					    e.printStackTrace();
					} catch (ClassNotFoundException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					}
				
				public void register4() throws IOException{
					String id = ois.readUTF();
					String name = ois.readUTF();
					String  time= ois.readUTF();
					Text_paper tp = null;
					String sql = "insert into text_paper values('"+id+"','"+name+"','"+time+"')";
					try {
						DataConnect.getStatment().executeUpdate(sql);
						oos.writeObject(new Text_paper(id,name,time));
						oos.flush();
					} catch (SQLException e) {
						// TODO Auto-generated catch block
					    oos.writeObject(null);
					    oos.flush();
					    e.printStackTrace();
					} catch (ClassNotFoundException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					}
				public void insert5() throws IOException{
					String id = ois.readUTF();
					String name = ois.readUTF();
					String  results= ois.readUTF();
					String  gradepoint= ois.readUTF();
					Exam_results er = null;
					String sql = "insert into exam_results values('"+id+"','"+name+"','"+results+"','"+gradepoint+"')";
					try {
						DataConnect.getStatment().executeUpdate(sql);
						oos.writeObject(new Exam_results(id,name,results,gradepoint));
						oos.flush();
					} catch (SQLException e) {
						// TODO Auto-generated catch block
					    oos.writeObject(null);
					    oos.flush();
					    e.printStackTrace();
					} catch (ClassNotFoundException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					}
				
	
					
     public static void main(String[] args) {
		try {
			new Server();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}


}