package server;

import java.io.*;


import java.net.*;
import java.util.ArrayList;
import java.util.Arrays;

import model.Admin_Imessage;
import model.Exam_results;
import model.Student_Imessage;
import model.Teacher_Imessage;
import model.Text_choose;
import model.Text_fill;
import model.Text_judge;
import model.Text_multiselect;
import model.Text_paper;



public class Client {
	
	ObjectOutputStream oos;
	ObjectInputStream ois;
	
	final int LOGIN = 1001;
	final int REGISTER = 1002;
	final int MODIFY= 1003;
	final int LOGINN= 1004;
	final int REGISTERR= 1005;
	final int LOGINNN= 1006;
	final int REGISTERRR= 1007;
	final int MODIFYY = 1009;
	final int INSERT = 1012;
	final int INSERTT = 1013;
	final int INSERTTT = 1014;
	final int INSERTTTT = 1015;
	final int MODIFYYY = 1016;
	final int MODIFYYYY = 1017;
	final int MODIFYYYYY = 1018;
	final int MODIFYYYYYY = 1019;
	final int REGISTERRRR = 1020;
	final int INSERTTTTT = 1021;
	
	
	Socket s;
	public Client() throws UnknownHostException, IOException{
		//s = new Socket("10.11.156.22",23456);
		s = new Socket("127.0.0.1",23456);
		oos = new ObjectOutputStream(s.getOutputStream());
		ois = new ObjectInputStream(s.getInputStream());
	}

	
	public Student_Imessage login(String id,String pw) throws IOException, ClassNotFoundException{
		oos.writeInt(LOGIN);
		oos.flush();
		oos.writeUTF(id);
		oos.flush();
		oos.writeUTF(pw);
		oos.flush();
		return (Student_Imessage) ois.readObject();
	}
	
	public Student_Imessage register(String name,String id, String pw, String headPhoto) throws IOException, ClassNotFoundException{
		oos.writeInt(REGISTER);
		oos.flush();
		oos.writeUTF(name);
		oos.flush();
		oos.writeUTF(id);
		oos.flush();
		oos.writeUTF(pw);
		oos.flush();
		oos.writeUTF(headPhoto);
		oos.flush();
		
		return (Student_Imessage) ois.readObject();
	}
	
	public Student_Imessage modify(String name,String id, String pw, String headPhoto) throws IOException, ClassNotFoundException{
		oos.writeInt(MODIFY);
		oos.flush();
		oos.writeUTF(id);
		oos.flush();
		oos.writeUTF(name);
		oos.flush();
		oos.writeUTF(pw);
		oos.flush();
		oos.writeUTF(headPhoto);
		oos.flush();
		return (Student_Imessage) ois.readObject();
}
	
	
	public Teacher_Imessage login2(String id,String pw) throws IOException, ClassNotFoundException{
		oos.writeInt(LOGINN);
		oos.flush();
		oos.writeUTF(id);
		oos.flush();
		oos.writeUTF(pw);
		oos.flush();
		return (Teacher_Imessage) ois.readObject();
	}
	
	public Teacher_Imessage modify2(String name,String id, String pw, String headPhoto) throws IOException, ClassNotFoundException{
		oos.writeInt(MODIFYY);
		oos.flush();
		oos.writeUTF(id);
		oos.flush();
		oos.writeUTF(name);
		oos.flush();
		oos.writeUTF(pw);
		oos.flush();
		oos.writeUTF(headPhoto);
		oos.flush();
		return (Teacher_Imessage) ois.readObject();
}
	public Teacher_Imessage register2(String name,String id, String pw, String headPhoto) throws IOException, ClassNotFoundException{
		oos.writeInt(REGISTERR);
		oos.flush();
		oos.writeUTF(name);
		oos.flush();
		oos.writeUTF(id);
		oos.flush();
		oos.writeUTF(pw);
		oos.flush();
		oos.writeUTF(headPhoto);
		oos.flush();
		
		return (Teacher_Imessage) ois.readObject();
	}
	
	public Admin_Imessage login3(String id,String pw) throws IOException, ClassNotFoundException{
		oos.writeInt(LOGINNN);
		oos.flush();
		oos.writeUTF(id);
		oos.flush();
		oos.writeUTF(pw);
		oos.flush();
		return (Admin_Imessage) ois.readObject();
	}
	
	public Admin_Imessage register3(String name,String id, String pw, String headPhoto) throws IOException, ClassNotFoundException{
		oos.writeInt(REGISTERRR);
		oos.flush();
		oos.writeUTF(name);
		oos.flush();
		oos.writeUTF(id);
		oos.flush();
		oos.writeUTF(pw);
		oos.flush();
		oos.writeUTF(headPhoto);
		oos.flush();
		
		return (Admin_Imessage) ois.readObject();
	}
	
	@SuppressWarnings("unchecked")
	public ArrayList<Student_Imessage> viewData() throws IOException, ClassNotFoundException {
		oos.writeInt(1000);
		oos.flush();
		ArrayList<Student_Imessage> Student_Imessage = (ArrayList<Student_Imessage>) ois.readObject();
		return Student_Imessage;
	}
	@SuppressWarnings("unchecked")
	public ArrayList<Teacher_Imessage> viewData1() throws IOException, ClassNotFoundException {
		oos.writeInt(1011);
		oos.flush();
		ArrayList<Teacher_Imessage> Teacher_Imessage = (ArrayList<Teacher_Imessage>) ois.readObject();
		return Teacher_Imessage;
	}
	
	public Text_multiselect insert1(String id,String topic, String option_A, String option_B, String option_C, String option_D,String option_E, String answer1 ,String answer2) throws IOException, ClassNotFoundException{
		oos.writeInt(INSERT);
		oos.flush();
		oos.writeUTF(id);
		oos.flush();
		oos.writeUTF(topic);
		oos.flush();
		oos.writeUTF(option_A);
		oos.flush();
		oos.writeUTF(option_B);
		oos.flush();
		oos.writeUTF(option_C);
		oos.flush();
		oos.writeUTF(option_D);
		oos.flush();
		oos.writeUTF(option_E);
		oos.flush();
		oos.writeUTF(answer1);
		oos.flush();
		oos.writeUTF(answer2);
		oos.flush();
		
		return (Text_multiselect) ois.readObject();
	}
	
	public Text_choose insert2(String id,String topic, String option_A, String option_B, String option_C, String option_D, String answer) throws IOException, ClassNotFoundException{
		oos.writeInt(INSERTT);
		oos.flush();
		oos.writeUTF(id);
		oos.flush();
		oos.writeUTF(topic);
		oos.flush();
		oos.writeUTF(option_A);
		oos.flush();
		oos.writeUTF(option_B);
		oos.flush();
		oos.writeUTF(option_C);
		oos.flush();
		oos.writeUTF(option_D);
		oos.flush();
		oos.writeUTF(answer);
		oos.flush();
		
		return (Text_choose) ois.readObject();
	}
	
	public Text_judge insert3(String id,String topic, String answer) throws IOException, ClassNotFoundException{
		oos.writeInt(INSERTTT);
		oos.flush();
		oos.writeUTF(id);
		oos.flush();
		oos.writeUTF(topic);
		oos.flush();
		oos.writeUTF(answer);
		oos.flush();
		
		return (Text_judge) ois.readObject();
	}
	
	public Text_fill insert4(String id,String topic, String answer) throws IOException, ClassNotFoundException{
		oos.writeInt(INSERTTTT);
		oos.flush();
		oos.writeUTF(id);
		oos.flush();
		oos.writeUTF(topic);
		oos.flush();
		oos.writeUTF(answer);
		oos.flush();
		
		return (Text_fill) ois.readObject();
	}
	public Text_multiselect modify3(String id,String topic, String option_A, String option_B, String option_C, String option_D,String option_E, String answer1, String answer2) throws IOException, ClassNotFoundException{
		oos.writeInt(MODIFYYY);
		oos.flush();
		oos.writeUTF(id);
		oos.flush();
		oos.writeUTF(topic);
		oos.flush();
		oos.writeUTF(option_A);
		oos.flush();
		oos.writeUTF(option_B);
		oos.flush();
		oos.writeUTF(option_C);
		oos.flush();
		oos.writeUTF(option_D);
		oos.flush();
		oos.writeUTF(option_E);
		oos.flush();
		oos.writeUTF(answer1);
		oos.flush();
		oos.writeUTF(answer2);
		oos.flush();
		return (Text_multiselect) ois.readObject();
	}
		
	public Text_choose modify4(String id,String topic, String option_A, String option_B, String option_C, String option_D, String answer) throws IOException, ClassNotFoundException{
			oos.writeInt(MODIFYYYY);
			oos.flush();
			oos.writeUTF(id);
			oos.flush();
			oos.writeUTF(topic);
			oos.flush();
			oos.writeUTF(option_A);
			oos.flush();
			oos.writeUTF(option_B);
			oos.flush();
			oos.writeUTF(option_C);
			oos.flush();
			oos.writeUTF(option_D);
			oos.flush();
			oos.writeUTF(answer);
			oos.flush();
			return (Text_choose) ois.readObject();
	}
			
	public Text_judge modify5(String id,String topic, String answer) throws IOException, ClassNotFoundException{
				oos.writeInt(MODIFYYYYY);
				oos.flush();
				oos.writeUTF(id);
				oos.flush();
				oos.writeUTF(topic);
				oos.flush();
				oos.writeUTF(answer);
				oos.flush();
				return (Text_judge) ois.readObject();
	}
				
	public Text_fill modify6(String id,String topic, String answer) throws IOException, ClassNotFoundException{
					oos.writeInt(MODIFYYYYYY);
					oos.flush();
					oos.writeUTF(id);
					oos.flush();
					oos.writeUTF(topic);
					oos.flush();
					oos.writeUTF(answer);
					oos.flush();
					return (Text_fill) ois.readObject();
	}
	
	public Text_paper register4(String id,String name,String time) throws IOException, ClassNotFoundException{
		oos.writeInt(REGISTERRRR);
		oos.flush();
		oos.writeUTF(id);
		oos.flush();
		oos.writeUTF(name);
		oos.flush();
		oos.writeUTF(time);
		oos.flush();
		
		return (Text_paper) ois.readObject();
	}
	@SuppressWarnings("unchecked")
	public ArrayList<Text_paper> viewData2() throws IOException, ClassNotFoundException {
		oos.writeInt(1023);
		oos.flush();
		ArrayList<Text_paper> Text_paper = (ArrayList<Text_paper>) ois.readObject();
		return Text_paper;
	}
	
	public Exam_results insert5(String id,String name, String result,String gradepoint) throws IOException, ClassNotFoundException{
		oos.writeInt(INSERTTTTT);
		oos.flush();
		oos.writeUTF(id);
		oos.flush();
		oos.writeUTF(name);
		oos.flush();
		oos.writeUTF(result);
		oos.flush();
		oos.writeUTF(gradepoint);
		oos.flush();
		
		return (Exam_results) ois.readObject();
	}
	@SuppressWarnings("unchecked")
	public ArrayList<Exam_results> viewData3() throws IOException, ClassNotFoundException {
		oos.writeInt(1022);
		oos.flush();
		ArrayList<Exam_results> Exam_results = (ArrayList<Exam_results>) ois.readObject();
		return Exam_results;
	}
}

