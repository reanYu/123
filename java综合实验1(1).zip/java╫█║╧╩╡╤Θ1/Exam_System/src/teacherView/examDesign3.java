/*
 * examDesign3.java
 *
 * Created on __DATE__, __TIME__
 */

package teacherView;

import java.io.IOException;

import javax.swing.JOptionPane;

import model.Student_Imessage;
import model.Text_choose;
import model.Text_fill;
import model.Text_judge;
import model.Text_multiselect;
import server.Client;
import studentView.Login_View1;
import studentView.register;

/**
 *
 * @author  __USER__
 */
public class examDesign3 extends javax.swing.JFrame {

	/** Creates new form examDesign3 */
	public examDesign3() {
		initComponents();
		this.setLocationRelativeTo(null);
	}

	//GEN-BEGIN:initComponents
	// <editor-fold defaultstate="collapsed" desc="Generated Code">
	private void initComponents() {

		jPanel1 = new javax.swing.JPanel();
		jLabel1 = new javax.swing.JLabel();
		jPanel2 = new javax.swing.JPanel();
		jTabbedPane1 = new javax.swing.JTabbedPane();
		jPanel4 = new javax.swing.JPanel();
		jLabel17 = new javax.swing.JLabel();
		jTextField16 = new javax.swing.JTextField();
		jLabel8 = new javax.swing.JLabel();
		jTextField7 = new javax.swing.JTextField();
		jLabel9 = new javax.swing.JLabel();
		jTextField8 = new javax.swing.JTextField();
		jTextField9 = new javax.swing.JTextField();
		jLabel10 = new javax.swing.JLabel();
		jLabel11 = new javax.swing.JLabel();
		jLabel12 = new javax.swing.JLabel();
		jLabel13 = new javax.swing.JLabel();
		jTextField10 = new javax.swing.JTextField();
		jTextField11 = new javax.swing.JTextField();
		jTextField12 = new javax.swing.JTextField();
		jButton2 = new javax.swing.JButton();
		jLabel22 = new javax.swing.JLabel();
		jTextField21 = new javax.swing.JTextField();
		jLabel23 = new javax.swing.JLabel();
		jTextField22 = new javax.swing.JTextField();
		jPanel5 = new javax.swing.JPanel();
		jLabel14 = new javax.swing.JLabel();
		jTextField13 = new javax.swing.JTextField();
		jLabel15 = new javax.swing.JLabel();
		jTextField14 = new javax.swing.JTextField();
		jButton3 = new javax.swing.JButton();
		jLabel18 = new javax.swing.JLabel();
		jTextField17 = new javax.swing.JTextField();
		jPanel6 = new javax.swing.JPanel();
		jLabel19 = new javax.swing.JLabel();
		jTextField18 = new javax.swing.JTextField();
		jLabel20 = new javax.swing.JLabel();
		jTextField19 = new javax.swing.JTextField();
		jLabel21 = new javax.swing.JLabel();
		jTextField20 = new javax.swing.JTextField();
		jButton4 = new javax.swing.JButton();
		jPanel3 = new javax.swing.JPanel();
		jLabel2 = new javax.swing.JLabel();
		jLabel3 = new javax.swing.JLabel();
		jLabel4 = new javax.swing.JLabel();
		jLabel5 = new javax.swing.JLabel();
		jLabel6 = new javax.swing.JLabel();
		jTextField1 = new javax.swing.JTextField();
		jTextField2 = new javax.swing.JTextField();
		jTextField3 = new javax.swing.JTextField();
		jTextField4 = new javax.swing.JTextField();
		jTextField5 = new javax.swing.JTextField();
		jLabel7 = new javax.swing.JLabel();
		jTextField6 = new javax.swing.JTextField();
		jButton1 = new javax.swing.JButton();
		jLabel16 = new javax.swing.JLabel();
		jTextField15 = new javax.swing.JTextField();
		jButton5 = new javax.swing.JButton();

		setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

		jPanel1.setBackground(new java.awt.Color(102, 153, 255));

		jLabel1.setFont(new java.awt.Font("����", 1, 40));
		jLabel1.setForeground(new java.awt.Color(255, 255, 255));
		jLabel1.setText("\u6dfb\u52a0\u95ee\u9898");

		javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(
				jPanel1);
		jPanel1.setLayout(jPanel1Layout);
		jPanel1Layout.setHorizontalGroup(jPanel1Layout.createParallelGroup(
				javax.swing.GroupLayout.Alignment.LEADING).addGroup(
				jPanel1Layout.createSequentialGroup().addGap(175, 175, 175)
						.addComponent(jLabel1).addContainerGap(185,
								Short.MAX_VALUE)));
		jPanel1Layout.setVerticalGroup(jPanel1Layout.createParallelGroup(
				javax.swing.GroupLayout.Alignment.LEADING).addGroup(
				jPanel1Layout.createSequentialGroup().addContainerGap()
						.addComponent(jLabel1).addContainerGap(
								javax.swing.GroupLayout.DEFAULT_SIZE,
								Short.MAX_VALUE)));

		jPanel2.setBackground(new java.awt.Color(255, 255, 255));

		jTabbedPane1.setFont(new java.awt.Font("Microsoft YaHei UI", 0, 22));

		jPanel4.setBackground(new java.awt.Color(255, 255, 255));

		jLabel17.setFont(new java.awt.Font("Microsoft YaHei UI", 0, 20));
		jLabel17.setText("\u5e8f\u53f7\uff1a");

		jTextField16.setFont(new java.awt.Font("Microsoft YaHei UI", 0, 20));

		jLabel8.setFont(new java.awt.Font("Microsoft YaHei UI", 0, 20));
		jLabel8.setText("\u9898\u76ee\uff1a");

		jTextField7.setFont(new java.awt.Font("Microsoft YaHei UI", 0, 20));

		jLabel9.setFont(new java.awt.Font("Microsoft YaHei UI", 0, 20));
		jLabel9.setText("\u9009\u9879A\uff1a");

		jTextField8.setFont(new java.awt.Font("Microsoft YaHei UI", 0, 20));

		jTextField9.setFont(new java.awt.Font("Microsoft YaHei UI", 0, 20));

		jLabel10.setFont(new java.awt.Font("Microsoft YaHei UI", 0, 20));
		jLabel10.setText("\u9009\u9879B\uff1a");

		jLabel11.setFont(new java.awt.Font("Microsoft YaHei UI", 0, 20));
		jLabel11.setText("\u9009\u9879C\uff1a");

		jLabel12.setFont(new java.awt.Font("Microsoft YaHei UI", 0, 20));
		jLabel12.setText("\u9009\u9879D\uff1a");

		jLabel13.setFont(new java.awt.Font("Microsoft YaHei UI", 0, 20));
		jLabel13.setText("\u7b54\u68481\uff1a");

		jTextField10.setFont(new java.awt.Font("Microsoft YaHei UI", 0, 20));

		jTextField11.setFont(new java.awt.Font("Microsoft YaHei UI", 0, 20));

		jTextField12.setFont(new java.awt.Font("Microsoft YaHei UI", 0, 20));

		jButton2.setBackground(new java.awt.Color(102, 153, 255));
		jButton2.setFont(new java.awt.Font("Microsoft YaHei UI", 0, 21));
		jButton2.setForeground(new java.awt.Color(255, 255, 255));
		jButton2.setText("\u4fdd\u5b58");
		jButton2.setBorderPainted(false);
		jButton2.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				jButton2ActionPerformed(evt);
			}
		});

		jLabel22.setFont(new java.awt.Font("Microsoft YaHei UI", 0, 20));
		jLabel22.setText("\u9009\u9879E\uff1a");

		jTextField21.setFont(new java.awt.Font("Microsoft YaHei UI", 0, 20));

		jLabel23.setFont(new java.awt.Font("Microsoft YaHei UI", 0, 20));
		jLabel23.setText("\u7b54\u68482\uff1a");

		jTextField22.setFont(new java.awt.Font("Microsoft YaHei UI", 0, 20));

		javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(
				jPanel4);
		jPanel4.setLayout(jPanel4Layout);
		jPanel4Layout
				.setHorizontalGroup(jPanel4Layout
						.createParallelGroup(
								javax.swing.GroupLayout.Alignment.LEADING)
						.addGroup(
								jPanel4Layout.createSequentialGroup().addGap(
										144, 144, 144).addComponent(jButton2,
										javax.swing.GroupLayout.PREFERRED_SIZE,
										132,
										javax.swing.GroupLayout.PREFERRED_SIZE)
										.addContainerGap(156, Short.MAX_VALUE))
						.addGroup(
								javax.swing.GroupLayout.Alignment.TRAILING,
								jPanel4Layout
										.createSequentialGroup()
										.addGroup(
												jPanel4Layout
														.createParallelGroup(
																javax.swing.GroupLayout.Alignment.TRAILING)
														.addGroup(
																javax.swing.GroupLayout.Alignment.LEADING,
																jPanel4Layout
																		.createSequentialGroup()
																		.addGap(
																				41,
																				41,
																				41)
																		.addComponent(
																				jLabel17)
																		.addPreferredGap(
																				javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																		.addComponent(
																				jTextField16,
																				javax.swing.GroupLayout.DEFAULT_SIZE,
																				312,
																				Short.MAX_VALUE))
														.addGroup(
																jPanel4Layout
																		.createSequentialGroup()
																		.addGap(
																				27,
																				27,
																				27)
																		.addGroup(
																				jPanel4Layout
																						.createParallelGroup(
																								javax.swing.GroupLayout.Alignment.LEADING)
																						.addGroup(
																								jPanel4Layout
																										.createSequentialGroup()
																										.addGroup(
																												jPanel4Layout
																														.createParallelGroup(
																																javax.swing.GroupLayout.Alignment.TRAILING)
																														.addComponent(
																																jLabel8)
																														.addComponent(
																																jLabel9)
																														.addComponent(
																																jLabel10))
																										.addPreferredGap(
																												javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																										.addGroup(
																												jPanel4Layout
																														.createParallelGroup(
																																javax.swing.GroupLayout.Alignment.LEADING)
																														.addComponent(
																																jTextField9,
																																javax.swing.GroupLayout.DEFAULT_SIZE,
																																312,
																																Short.MAX_VALUE)
																														.addComponent(
																																jTextField8,
																																javax.swing.GroupLayout.DEFAULT_SIZE,
																																312,
																																Short.MAX_VALUE)
																														.addComponent(
																																jTextField7,
																																javax.swing.GroupLayout.DEFAULT_SIZE,
																																312,
																																Short.MAX_VALUE)))
																						.addGroup(
																								javax.swing.GroupLayout.Alignment.TRAILING,
																								jPanel4Layout
																										.createSequentialGroup()
																										.addGap(
																												2,
																												2,
																												2)
																										.addComponent(
																												jLabel11)
																										.addPreferredGap(
																												javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																										.addComponent(
																												jTextField12,
																												javax.swing.GroupLayout.DEFAULT_SIZE,
																												311,
																												Short.MAX_VALUE))
																						.addGroup(
																								jPanel4Layout
																										.createSequentialGroup()
																										.addGroup(
																												jPanel4Layout
																														.createParallelGroup(
																																javax.swing.GroupLayout.Alignment.TRAILING)
																														.addComponent(
																																jLabel13)
																														.addGroup(
																																jPanel4Layout
																																		.createParallelGroup(
																																				javax.swing.GroupLayout.Alignment.LEADING)
																																		.addComponent(
																																				jLabel22)
																																		.addComponent(
																																				jLabel12)))
																										.addPreferredGap(
																												javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																										.addGroup(
																												jPanel4Layout
																														.createParallelGroup(
																																javax.swing.GroupLayout.Alignment.LEADING)
																														.addComponent(
																																jTextField21,
																																javax.swing.GroupLayout.DEFAULT_SIZE,
																																311,
																																Short.MAX_VALUE)
																														.addComponent(
																																jTextField11,
																																javax.swing.GroupLayout.DEFAULT_SIZE,
																																311,
																																Short.MAX_VALUE)
																														.addGroup(
																																jPanel4Layout
																																		.createSequentialGroup()
																																		.addComponent(
																																				jTextField10,
																																				javax.swing.GroupLayout.PREFERRED_SIZE,
																																				108,
																																				javax.swing.GroupLayout.PREFERRED_SIZE)
																																		.addGap(
																																				18,
																																				18,
																																				18)
																																		.addComponent(
																																				jLabel23)
																																		.addPreferredGap(
																																				javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																																		.addComponent(
																																				jTextField22,
																																				javax.swing.GroupLayout.DEFAULT_SIZE,
																																				108,
																																				Short.MAX_VALUE)))))))
										.addGap(14, 14, 14)));
		jPanel4Layout
				.setVerticalGroup(jPanel4Layout
						.createParallelGroup(
								javax.swing.GroupLayout.Alignment.LEADING)
						.addGroup(
								jPanel4Layout
										.createSequentialGroup()
										.addGap(41, 41, 41)
										.addGroup(
												jPanel4Layout
														.createParallelGroup(
																javax.swing.GroupLayout.Alignment.BASELINE)
														.addComponent(jLabel17)
														.addComponent(
																jTextField16,
																javax.swing.GroupLayout.PREFERRED_SIZE,
																javax.swing.GroupLayout.DEFAULT_SIZE,
																javax.swing.GroupLayout.PREFERRED_SIZE))
										.addPreferredGap(
												javax.swing.LayoutStyle.ComponentPlacement.RELATED)
										.addGroup(
												jPanel4Layout
														.createParallelGroup(
																javax.swing.GroupLayout.Alignment.BASELINE)
														.addComponent(jLabel8)
														.addComponent(
																jTextField7,
																javax.swing.GroupLayout.PREFERRED_SIZE,
																javax.swing.GroupLayout.DEFAULT_SIZE,
																javax.swing.GroupLayout.PREFERRED_SIZE))
										.addPreferredGap(
												javax.swing.LayoutStyle.ComponentPlacement.RELATED)
										.addGroup(
												jPanel4Layout
														.createParallelGroup(
																javax.swing.GroupLayout.Alignment.BASELINE)
														.addComponent(jLabel9)
														.addComponent(
																jTextField8,
																javax.swing.GroupLayout.PREFERRED_SIZE,
																javax.swing.GroupLayout.DEFAULT_SIZE,
																javax.swing.GroupLayout.PREFERRED_SIZE))
										.addPreferredGap(
												javax.swing.LayoutStyle.ComponentPlacement.RELATED)
										.addGroup(
												jPanel4Layout
														.createParallelGroup(
																javax.swing.GroupLayout.Alignment.BASELINE)
														.addComponent(jLabel10)
														.addComponent(
																jTextField9,
																javax.swing.GroupLayout.PREFERRED_SIZE,
																javax.swing.GroupLayout.DEFAULT_SIZE,
																javax.swing.GroupLayout.PREFERRED_SIZE))
										.addPreferredGap(
												javax.swing.LayoutStyle.ComponentPlacement.RELATED)
										.addGroup(
												jPanel4Layout
														.createParallelGroup(
																javax.swing.GroupLayout.Alignment.BASELINE)
														.addComponent(jLabel11)
														.addComponent(
																jTextField12,
																javax.swing.GroupLayout.PREFERRED_SIZE,
																javax.swing.GroupLayout.DEFAULT_SIZE,
																javax.swing.GroupLayout.PREFERRED_SIZE))
										.addPreferredGap(
												javax.swing.LayoutStyle.ComponentPlacement.RELATED)
										.addGroup(
												jPanel4Layout
														.createParallelGroup(
																javax.swing.GroupLayout.Alignment.BASELINE)
														.addComponent(jLabel12)
														.addComponent(
																jTextField11,
																javax.swing.GroupLayout.PREFERRED_SIZE,
																javax.swing.GroupLayout.DEFAULT_SIZE,
																javax.swing.GroupLayout.PREFERRED_SIZE))
										.addPreferredGap(
												javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
										.addGroup(
												jPanel4Layout
														.createParallelGroup(
																javax.swing.GroupLayout.Alignment.BASELINE)
														.addComponent(
																jTextField21,
																javax.swing.GroupLayout.PREFERRED_SIZE,
																javax.swing.GroupLayout.DEFAULT_SIZE,
																javax.swing.GroupLayout.PREFERRED_SIZE)
														.addComponent(jLabel22))
										.addGap(15, 15, 15)
										.addGroup(
												jPanel4Layout
														.createParallelGroup(
																javax.swing.GroupLayout.Alignment.BASELINE)
														.addComponent(jLabel13)
														.addComponent(
																jTextField10,
																javax.swing.GroupLayout.PREFERRED_SIZE,
																javax.swing.GroupLayout.DEFAULT_SIZE,
																javax.swing.GroupLayout.PREFERRED_SIZE)
														.addComponent(jLabel23)
														.addComponent(
																jTextField22,
																javax.swing.GroupLayout.PREFERRED_SIZE,
																javax.swing.GroupLayout.DEFAULT_SIZE,
																javax.swing.GroupLayout.PREFERRED_SIZE))
										.addGap(6, 6, 6)
										.addComponent(
												jButton2,
												javax.swing.GroupLayout.PREFERRED_SIZE,
												42,
												javax.swing.GroupLayout.PREFERRED_SIZE)
										.addContainerGap()));

		jTabbedPane1.addTab(" \u591a\u9009\u9898 ", jPanel4);

		jPanel5.setBackground(new java.awt.Color(255, 255, 255));

		jLabel14.setFont(new java.awt.Font("Microsoft YaHei UI", 0, 21));
		jLabel14.setText("\u9898\u76ee\uff1a");

		jTextField13.setFont(new java.awt.Font("Microsoft YaHei UI", 0, 20));

		jLabel15.setFont(new java.awt.Font("Microsoft YaHei UI", 0, 21));
		jLabel15.setText("\u7b54\u6848\uff1a");

		jTextField14.setFont(new java.awt.Font("Microsoft YaHei UI", 0, 20));

		jButton3.setBackground(new java.awt.Color(102, 153, 255));
		jButton3.setFont(new java.awt.Font("Microsoft YaHei UI", 0, 21));
		jButton3.setForeground(new java.awt.Color(255, 255, 255));
		jButton3.setText("\u4fdd\u5b58");
		jButton3.setBorderPainted(false);
		jButton3.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				jButton3ActionPerformed(evt);
			}
		});

		jLabel18.setFont(new java.awt.Font("Microsoft YaHei UI", 0, 21));
		jLabel18.setText("\u5e8f\u53f7\uff1a");

		jTextField17.setFont(new java.awt.Font("Microsoft YaHei UI", 0, 20));

		javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(
				jPanel5);
		jPanel5.setLayout(jPanel5Layout);
		jPanel5Layout
				.setHorizontalGroup(jPanel5Layout
						.createParallelGroup(
								javax.swing.GroupLayout.Alignment.LEADING)
						.addGroup(
								javax.swing.GroupLayout.Alignment.TRAILING,
								jPanel5Layout
										.createSequentialGroup()
										.addGap(54, 54, 54)
										.addGroup(
												jPanel5Layout
														.createParallelGroup(
																javax.swing.GroupLayout.Alignment.LEADING)
														.addGroup(
																jPanel5Layout
																		.createSequentialGroup()
																		.addComponent(
																				jLabel18)
																		.addPreferredGap(
																				javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																		.addComponent(
																				jTextField17,
																				javax.swing.GroupLayout.PREFERRED_SIZE,
																				259,
																				javax.swing.GroupLayout.PREFERRED_SIZE))
														.addGroup(
																javax.swing.GroupLayout.Alignment.TRAILING,
																jPanel5Layout
																		.createSequentialGroup()
																		.addGroup(
																				jPanel5Layout
																						.createParallelGroup(
																								javax.swing.GroupLayout.Alignment.TRAILING)
																						.addComponent(
																								jLabel15)
																						.addComponent(
																								jLabel14))
																		.addPreferredGap(
																				javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																		.addGroup(
																				jPanel5Layout
																						.createParallelGroup(
																								javax.swing.GroupLayout.Alignment.TRAILING)
																						.addComponent(
																								jTextField14,
																								javax.swing.GroupLayout.Alignment.LEADING,
																								javax.swing.GroupLayout.DEFAULT_SIZE,
																								262,
																								Short.MAX_VALUE)
																						.addComponent(
																								jTextField13,
																								javax.swing.GroupLayout.DEFAULT_SIZE,
																								262,
																								Short.MAX_VALUE))))
										.addGap(48, 48, 48)).addGroup(
								jPanel5Layout.createSequentialGroup().addGap(
										150, 150, 150).addComponent(jButton3,
										javax.swing.GroupLayout.PREFERRED_SIZE,
										127,
										javax.swing.GroupLayout.PREFERRED_SIZE)
										.addContainerGap(155, Short.MAX_VALUE)));
		jPanel5Layout
				.setVerticalGroup(jPanel5Layout
						.createParallelGroup(
								javax.swing.GroupLayout.Alignment.LEADING)
						.addGroup(
								jPanel5Layout
										.createSequentialGroup()
										.addGap(45, 45, 45)
										.addGroup(
												jPanel5Layout
														.createParallelGroup(
																javax.swing.GroupLayout.Alignment.BASELINE)
														.addComponent(jLabel18)
														.addComponent(
																jTextField17,
																javax.swing.GroupLayout.PREFERRED_SIZE,
																39,
																javax.swing.GroupLayout.PREFERRED_SIZE))
										.addGap(28, 28, 28)
										.addGroup(
												jPanel5Layout
														.createParallelGroup(
																javax.swing.GroupLayout.Alignment.BASELINE)
														.addComponent(jLabel14)
														.addComponent(
																jTextField13,
																javax.swing.GroupLayout.PREFERRED_SIZE,
																40,
																javax.swing.GroupLayout.PREFERRED_SIZE))
										.addGap(30, 30, 30)
										.addGroup(
												jPanel5Layout
														.createParallelGroup(
																javax.swing.GroupLayout.Alignment.BASELINE)
														.addComponent(
																jTextField14,
																javax.swing.GroupLayout.PREFERRED_SIZE,
																38,
																javax.swing.GroupLayout.PREFERRED_SIZE)
														.addComponent(jLabel15))
										.addGap(67, 67, 67)
										.addComponent(
												jButton3,
												javax.swing.GroupLayout.PREFERRED_SIZE,
												45,
												javax.swing.GroupLayout.PREFERRED_SIZE)
										.addContainerGap(92, Short.MAX_VALUE)));

		jTabbedPane1.addTab(" \u586b\u7a7a\u9898 ", jPanel5);

		jPanel6.setBackground(new java.awt.Color(255, 255, 255));

		jLabel19.setFont(new java.awt.Font("Microsoft YaHei UI", 0, 21));
		jLabel19.setText("\u5e8f\u53f7\uff1a");

		jTextField18.setFont(new java.awt.Font("Microsoft YaHei UI", 0, 20));

		jLabel20.setFont(new java.awt.Font("Microsoft YaHei UI", 0, 21));
		jLabel20.setText("\u9898\u76ee\uff1a");

		jTextField19.setFont(new java.awt.Font("Microsoft YaHei UI", 0, 20));

		jLabel21.setFont(new java.awt.Font("Microsoft YaHei UI", 0, 21));
		jLabel21.setText("\u7b54\u6848\uff1a");

		jTextField20.setFont(new java.awt.Font("Microsoft YaHei UI", 0, 20));

		jButton4.setBackground(new java.awt.Color(102, 153, 255));
		jButton4.setFont(new java.awt.Font("Microsoft YaHei UI", 0, 21));
		jButton4.setForeground(new java.awt.Color(255, 255, 255));
		jButton4.setText("\u4fdd\u5b58");
		jButton4.setBorderPainted(false);
		jButton4.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				jButton4ActionPerformed(evt);
			}
		});

		javax.swing.GroupLayout jPanel6Layout = new javax.swing.GroupLayout(
				jPanel6);
		jPanel6.setLayout(jPanel6Layout);
		jPanel6Layout
				.setHorizontalGroup(jPanel6Layout
						.createParallelGroup(
								javax.swing.GroupLayout.Alignment.LEADING)
						.addGroup(
								javax.swing.GroupLayout.Alignment.TRAILING,
								jPanel6Layout
										.createSequentialGroup()
										.addGap(54, 54, 54)
										.addGroup(
												jPanel6Layout
														.createParallelGroup(
																javax.swing.GroupLayout.Alignment.LEADING)
														.addGroup(
																jPanel6Layout
																		.createSequentialGroup()
																		.addComponent(
																				jLabel19)
																		.addPreferredGap(
																				javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																		.addComponent(
																				jTextField18,
																				javax.swing.GroupLayout.PREFERRED_SIZE,
																				259,
																				javax.swing.GroupLayout.PREFERRED_SIZE))
														.addGroup(
																javax.swing.GroupLayout.Alignment.TRAILING,
																jPanel6Layout
																		.createSequentialGroup()
																		.addGroup(
																				jPanel6Layout
																						.createParallelGroup(
																								javax.swing.GroupLayout.Alignment.TRAILING)
																						.addComponent(
																								jLabel21)
																						.addComponent(
																								jLabel20))
																		.addPreferredGap(
																				javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																		.addGroup(
																				jPanel6Layout
																						.createParallelGroup(
																								javax.swing.GroupLayout.Alignment.TRAILING)
																						.addComponent(
																								jTextField20,
																								javax.swing.GroupLayout.Alignment.LEADING,
																								javax.swing.GroupLayout.DEFAULT_SIZE,
																								262,
																								Short.MAX_VALUE)
																						.addComponent(
																								jTextField19,
																								javax.swing.GroupLayout.DEFAULT_SIZE,
																								262,
																								Short.MAX_VALUE))))
										.addGap(48, 48, 48)).addGroup(
								jPanel6Layout.createSequentialGroup().addGap(
										150, 150, 150).addComponent(jButton4,
										javax.swing.GroupLayout.PREFERRED_SIZE,
										127,
										javax.swing.GroupLayout.PREFERRED_SIZE)
										.addContainerGap(155, Short.MAX_VALUE)));
		jPanel6Layout
				.setVerticalGroup(jPanel6Layout
						.createParallelGroup(
								javax.swing.GroupLayout.Alignment.LEADING)
						.addGroup(
								jPanel6Layout
										.createSequentialGroup()
										.addGap(45, 45, 45)
										.addGroup(
												jPanel6Layout
														.createParallelGroup(
																javax.swing.GroupLayout.Alignment.BASELINE)
														.addComponent(jLabel19)
														.addComponent(
																jTextField18,
																javax.swing.GroupLayout.PREFERRED_SIZE,
																39,
																javax.swing.GroupLayout.PREFERRED_SIZE))
										.addGap(28, 28, 28)
										.addGroup(
												jPanel6Layout
														.createParallelGroup(
																javax.swing.GroupLayout.Alignment.BASELINE)
														.addComponent(jLabel20)
														.addComponent(
																jTextField19,
																javax.swing.GroupLayout.PREFERRED_SIZE,
																40,
																javax.swing.GroupLayout.PREFERRED_SIZE))
										.addGap(30, 30, 30)
										.addGroup(
												jPanel6Layout
														.createParallelGroup(
																javax.swing.GroupLayout.Alignment.BASELINE)
														.addComponent(
																jTextField20,
																javax.swing.GroupLayout.PREFERRED_SIZE,
																38,
																javax.swing.GroupLayout.PREFERRED_SIZE)
														.addComponent(jLabel21))
										.addGap(67, 67, 67)
										.addComponent(
												jButton4,
												javax.swing.GroupLayout.PREFERRED_SIZE,
												45,
												javax.swing.GroupLayout.PREFERRED_SIZE)
										.addContainerGap(92, Short.MAX_VALUE)));

		jTabbedPane1.addTab(" \u5224\u65ad\u9898 ", jPanel6);

		jPanel3.setBackground(new java.awt.Color(255, 255, 255));

		jLabel2.setFont(new java.awt.Font("Microsoft YaHei UI", 0, 20));
		jLabel2.setText("\u9898\u76ee\uff1a");

		jLabel3.setFont(new java.awt.Font("Microsoft YaHei UI", 0, 20));
		jLabel3.setText("\u9009\u9879A\uff1a");

		jLabel4.setFont(new java.awt.Font("Microsoft YaHei UI", 0, 20));
		jLabel4.setText("\u9009\u9879B\uff1a");

		jLabel5.setFont(new java.awt.Font("Microsoft YaHei UI", 0, 20));
		jLabel5.setText("\u9009\u9879C\uff1a");

		jLabel6.setFont(new java.awt.Font("Microsoft YaHei UI", 0, 20));
		jLabel6.setText("\u9009\u9879D\uff1a");

		jTextField1.setFont(new java.awt.Font("Microsoft YaHei UI", 0, 20));

		jTextField2.setFont(new java.awt.Font("Microsoft YaHei UI", 0, 20));

		jTextField3.setFont(new java.awt.Font("Microsoft YaHei UI", 0, 20));

		jTextField4.setFont(new java.awt.Font("Microsoft YaHei UI", 0, 20));

		jTextField5.setFont(new java.awt.Font("Microsoft YaHei UI", 0, 20));

		jLabel7.setFont(new java.awt.Font("Microsoft YaHei UI", 0, 20));
		jLabel7.setText("\u7b54\u6848\uff1a");

		jTextField6.setFont(new java.awt.Font("Microsoft YaHei UI", 0, 20));

		jButton1.setBackground(new java.awt.Color(102, 153, 255));
		jButton1.setFont(new java.awt.Font("Microsoft YaHei UI", 0, 21));
		jButton1.setForeground(new java.awt.Color(255, 255, 255));
		jButton1.setText("\u4fdd\u5b58");
		jButton1.setBorderPainted(false);
		jButton1.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				jButton1ActionPerformed(evt);
			}
		});

		jLabel16.setFont(new java.awt.Font("Microsoft YaHei UI", 0, 20));
		jLabel16.setText("\u5e8f\u53f7\uff1a");

		jTextField15.setFont(new java.awt.Font("Microsoft YaHei UI", 0, 20));
		jTextField15.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				jTextField15ActionPerformed(evt);
			}
		});

		javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(
				jPanel3);
		jPanel3.setLayout(jPanel3Layout);
		jPanel3Layout
				.setHorizontalGroup(jPanel3Layout
						.createParallelGroup(
								javax.swing.GroupLayout.Alignment.LEADING)
						.addGroup(
								jPanel3Layout
										.createSequentialGroup()
										.addGap(41, 41, 41)
										.addComponent(jLabel16)
										.addPreferredGap(
												javax.swing.LayoutStyle.ComponentPlacement.RELATED)
										.addComponent(
												jTextField15,
												javax.swing.GroupLayout.DEFAULT_SIZE,
												297, Short.MAX_VALUE).addGap(
												29, 29, 29))
						.addGroup(
								jPanel3Layout
										.createSequentialGroup()
										.addGap(27, 27, 27)
										.addGroup(
												jPanel3Layout
														.createParallelGroup(
																javax.swing.GroupLayout.Alignment.LEADING)
														.addGroup(
																jPanel3Layout
																		.createSequentialGroup()
																		.addGroup(
																				jPanel3Layout
																						.createParallelGroup(
																								javax.swing.GroupLayout.Alignment.TRAILING)
																						.addComponent(
																								jLabel2)
																						.addComponent(
																								jLabel3)
																						.addComponent(
																								jLabel4))
																		.addPreferredGap(
																				javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																		.addGroup(
																				jPanel3Layout
																						.createParallelGroup(
																								javax.swing.GroupLayout.Alignment.LEADING)
																						.addComponent(
																								jTextField3,
																								javax.swing.GroupLayout.DEFAULT_SIZE,
																								297,
																								Short.MAX_VALUE)
																						.addComponent(
																								jTextField2,
																								javax.swing.GroupLayout.DEFAULT_SIZE,
																								297,
																								Short.MAX_VALUE)
																						.addComponent(
																								jTextField1,
																								javax.swing.GroupLayout.DEFAULT_SIZE,
																								297,
																								Short.MAX_VALUE)))
														.addGroup(
																javax.swing.GroupLayout.Alignment.TRAILING,
																jPanel3Layout
																		.createSequentialGroup()
																		.addGap(
																				2,
																				2,
																				2)
																		.addComponent(
																				jLabel5)
																		.addPreferredGap(
																				javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																		.addComponent(
																				jTextField4,
																				javax.swing.GroupLayout.DEFAULT_SIZE,
																				296,
																				Short.MAX_VALUE))
														.addGroup(
																javax.swing.GroupLayout.Alignment.TRAILING,
																jPanel3Layout
																		.createSequentialGroup()
																		.addGroup(
																				jPanel3Layout
																						.createParallelGroup(
																								javax.swing.GroupLayout.Alignment.TRAILING)
																						.addComponent(
																								jLabel6)
																						.addComponent(
																								jLabel7))
																		.addPreferredGap(
																				javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																		.addGroup(
																				jPanel3Layout
																						.createParallelGroup(
																								javax.swing.GroupLayout.Alignment.LEADING)
																						.addComponent(
																								jTextField6,
																								javax.swing.GroupLayout.DEFAULT_SIZE,
																								296,
																								Short.MAX_VALUE)
																						.addComponent(
																								jTextField5,
																								javax.swing.GroupLayout.DEFAULT_SIZE,
																								296,
																								Short.MAX_VALUE))))
										.addGap(29, 29, 29))
						.addGroup(
								javax.swing.GroupLayout.Alignment.TRAILING,
								jPanel3Layout
										.createSequentialGroup()
										.addContainerGap(162, Short.MAX_VALUE)
										.addComponent(
												jButton1,
												javax.swing.GroupLayout.PREFERRED_SIZE,
												132,
												javax.swing.GroupLayout.PREFERRED_SIZE)
										.addGap(138, 138, 138)));
		jPanel3Layout
				.setVerticalGroup(jPanel3Layout
						.createParallelGroup(
								javax.swing.GroupLayout.Alignment.LEADING)
						.addGroup(
								jPanel3Layout
										.createSequentialGroup()
										.addGap(41, 41, 41)
										.addGroup(
												jPanel3Layout
														.createParallelGroup(
																javax.swing.GroupLayout.Alignment.BASELINE)
														.addComponent(
																jTextField15,
																javax.swing.GroupLayout.PREFERRED_SIZE,
																javax.swing.GroupLayout.DEFAULT_SIZE,
																javax.swing.GroupLayout.PREFERRED_SIZE)
														.addComponent(jLabel16))
										.addPreferredGap(
												javax.swing.LayoutStyle.ComponentPlacement.RELATED)
										.addGroup(
												jPanel3Layout
														.createParallelGroup(
																javax.swing.GroupLayout.Alignment.BASELINE)
														.addComponent(jLabel2)
														.addComponent(
																jTextField1,
																javax.swing.GroupLayout.PREFERRED_SIZE,
																javax.swing.GroupLayout.DEFAULT_SIZE,
																javax.swing.GroupLayout.PREFERRED_SIZE))
										.addPreferredGap(
												javax.swing.LayoutStyle.ComponentPlacement.RELATED)
										.addGroup(
												jPanel3Layout
														.createParallelGroup(
																javax.swing.GroupLayout.Alignment.BASELINE)
														.addComponent(jLabel3)
														.addComponent(
																jTextField2,
																javax.swing.GroupLayout.PREFERRED_SIZE,
																javax.swing.GroupLayout.DEFAULT_SIZE,
																javax.swing.GroupLayout.PREFERRED_SIZE))
										.addPreferredGap(
												javax.swing.LayoutStyle.ComponentPlacement.RELATED)
										.addGroup(
												jPanel3Layout
														.createParallelGroup(
																javax.swing.GroupLayout.Alignment.BASELINE)
														.addComponent(jLabel4)
														.addComponent(
																jTextField3,
																javax.swing.GroupLayout.PREFERRED_SIZE,
																javax.swing.GroupLayout.DEFAULT_SIZE,
																javax.swing.GroupLayout.PREFERRED_SIZE))
										.addPreferredGap(
												javax.swing.LayoutStyle.ComponentPlacement.RELATED)
										.addGroup(
												jPanel3Layout
														.createParallelGroup(
																javax.swing.GroupLayout.Alignment.BASELINE)
														.addComponent(jLabel5)
														.addComponent(
																jTextField4,
																javax.swing.GroupLayout.PREFERRED_SIZE,
																javax.swing.GroupLayout.DEFAULT_SIZE,
																javax.swing.GroupLayout.PREFERRED_SIZE))
										.addPreferredGap(
												javax.swing.LayoutStyle.ComponentPlacement.RELATED)
										.addGroup(
												jPanel3Layout
														.createParallelGroup(
																javax.swing.GroupLayout.Alignment.BASELINE)
														.addComponent(jLabel6)
														.addComponent(
																jTextField5,
																javax.swing.GroupLayout.PREFERRED_SIZE,
																javax.swing.GroupLayout.DEFAULT_SIZE,
																javax.swing.GroupLayout.PREFERRED_SIZE))
										.addPreferredGap(
												javax.swing.LayoutStyle.ComponentPlacement.RELATED)
										.addGroup(
												jPanel3Layout
														.createParallelGroup(
																javax.swing.GroupLayout.Alignment.BASELINE)
														.addComponent(jLabel7)
														.addComponent(
																jTextField6,
																javax.swing.GroupLayout.PREFERRED_SIZE,
																javax.swing.GroupLayout.DEFAULT_SIZE,
																javax.swing.GroupLayout.PREFERRED_SIZE))
										.addGap(18, 18, 18)
										.addComponent(
												jButton1,
												javax.swing.GroupLayout.PREFERRED_SIZE,
												42,
												javax.swing.GroupLayout.PREFERRED_SIZE)
										.addGap(44, 44, 44)));

		jTabbedPane1.addTab(" \u5355\u9009\u9898 ", jPanel3);

		jButton5.setBackground(new java.awt.Color(102, 153, 255));
		jButton5.setFont(new java.awt.Font("Microsoft YaHei UI", 0, 21));
		jButton5.setForeground(new java.awt.Color(255, 255, 255));
		jButton5.setText("\u8fd4\u56de");
		jButton5.setBorderPainted(false);
		jButton5.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				jButton5ActionPerformed(evt);
			}
		});

		javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(
				jPanel2);
		jPanel2.setLayout(jPanel2Layout);
		jPanel2Layout.setHorizontalGroup(jPanel2Layout.createParallelGroup(
				javax.swing.GroupLayout.Alignment.LEADING).addGroup(
				jPanel2Layout.createSequentialGroup().addContainerGap(384,
						Short.MAX_VALUE).addComponent(jButton5,
						javax.swing.GroupLayout.PREFERRED_SIZE, 132,
						javax.swing.GroupLayout.PREFERRED_SIZE)
						.addContainerGap()).addGroup(
				jPanel2Layout.createSequentialGroup().addGap(39, 39, 39)
						.addComponent(jTabbedPane1,
								javax.swing.GroupLayout.PREFERRED_SIZE, 437,
								javax.swing.GroupLayout.PREFERRED_SIZE)
						.addContainerGap(52, Short.MAX_VALUE)));
		jPanel2Layout.setVerticalGroup(jPanel2Layout.createParallelGroup(
				javax.swing.GroupLayout.Alignment.LEADING).addGroup(
				jPanel2Layout.createSequentialGroup().addComponent(jButton5,
						javax.swing.GroupLayout.PREFERRED_SIZE, 42,
						javax.swing.GroupLayout.PREFERRED_SIZE).addGap(18, 18,
						18).addComponent(jTabbedPane1,
						javax.swing.GroupLayout.PREFERRED_SIZE, 467,
						javax.swing.GroupLayout.PREFERRED_SIZE)
						.addContainerGap(47, Short.MAX_VALUE)));

		javax.swing.GroupLayout layout = new javax.swing.GroupLayout(
				getContentPane());
		getContentPane().setLayout(layout);
		layout.setHorizontalGroup(layout.createParallelGroup(
				javax.swing.GroupLayout.Alignment.LEADING).addComponent(
				jPanel1, javax.swing.GroupLayout.Alignment.TRAILING,
				javax.swing.GroupLayout.DEFAULT_SIZE,
				javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
				.addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE,
						javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE));
		layout.setVerticalGroup(layout.createParallelGroup(
				javax.swing.GroupLayout.Alignment.LEADING).addGroup(
				layout.createSequentialGroup().addComponent(jPanel1,
						javax.swing.GroupLayout.PREFERRED_SIZE,
						javax.swing.GroupLayout.DEFAULT_SIZE,
						javax.swing.GroupLayout.PREFERRED_SIZE).addGap(3, 3, 3)
						.addComponent(jPanel2,
								javax.swing.GroupLayout.PREFERRED_SIZE,
								javax.swing.GroupLayout.DEFAULT_SIZE,
								javax.swing.GroupLayout.PREFERRED_SIZE)));

		pack();
	}// </editor-fold>
	//GEN-END:initComponents

	private void jTextField15ActionPerformed(java.awt.event.ActionEvent evt) {
		// TODO add your handling code here:
	}

	private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {
		try {
			Client c = new Client();
			Text_fill tf = c.insert4(this.jTextField17.getText(),
					this.jTextField13.getText(), this.jTextField14.getText());
			if (tf == null)
				JOptionPane.showMessageDialog(this, "����ʧ��");
			else {
				JOptionPane.showMessageDialog(this, "���ӳɹ�");
			}

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {
		try {
			Client c = new Client();
			Text_judge tj = c.insert3(this.jTextField18.getText(),
					this.jTextField19.getText(), this.jTextField20.getText());
			if (tj == null)
				JOptionPane.showMessageDialog(this, "����ʧ��");
			else {
				JOptionPane.showMessageDialog(this, "���ӳɹ�");
			}

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {
		try {
			Client c = new Client();
			Text_choose tc = c.insert2(this.jTextField15.getText(),
					this.jTextField1.getText(), this.jTextField2.getText(),
					this.jTextField3.getText(), this.jTextField4.getText(),
					this.jTextField5.getText(), this.jTextField6.getText());
			if (tc == null)
				JOptionPane.showMessageDialog(this, "����ʧ��");
			else {
				JOptionPane.showMessageDialog(this, "���ӳɹ�");
			}

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {
		try {
			Client c = new Client();
			Text_multiselect tmi = c.insert1(this.jTextField16.getText(),
					this.jTextField7.getText(), this.jTextField8.getText(),
					this.jTextField9.getText(), this.jTextField12.getText(),
					this.jTextField11.getText(), this.jTextField21.getText(),
					this.jTextField10.getText(), this.jTextField22.getText());
			if (tmi == null) {
				JOptionPane.showMessageDialog(this, "����ʧ��");
			} else {
				JOptionPane.showMessageDialog(this, "���ӳɹ�");
			}

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	private void jButton5ActionPerformed(java.awt.event.ActionEvent evt) {
		examDesign2 frame5 = new examDesign2();
		frame5.setVisible(true);
		dispose();
	}

	/**
	 * @param args the command line arguments
	 */
	public static void main(String args[]) {
		java.awt.EventQueue.invokeLater(new Runnable() {
			public void run() {
				new examDesign3().setVisible(true);
			}
		});
	}

	//GEN-BEGIN:variables
	// Variables declaration - do not modify
	private javax.swing.JButton jButton1;
	private javax.swing.JButton jButton2;
	private javax.swing.JButton jButton3;
	private javax.swing.JButton jButton4;
	private javax.swing.JButton jButton5;
	private javax.swing.JLabel jLabel1;
	private javax.swing.JLabel jLabel10;
	private javax.swing.JLabel jLabel11;
	private javax.swing.JLabel jLabel12;
	private javax.swing.JLabel jLabel13;
	private javax.swing.JLabel jLabel14;
	private javax.swing.JLabel jLabel15;
	private javax.swing.JLabel jLabel16;
	private javax.swing.JLabel jLabel17;
	private javax.swing.JLabel jLabel18;
	private javax.swing.JLabel jLabel19;
	private javax.swing.JLabel jLabel2;
	private javax.swing.JLabel jLabel20;
	private javax.swing.JLabel jLabel21;
	private javax.swing.JLabel jLabel22;
	private javax.swing.JLabel jLabel23;
	private javax.swing.JLabel jLabel3;
	private javax.swing.JLabel jLabel4;
	private javax.swing.JLabel jLabel5;
	private javax.swing.JLabel jLabel6;
	private javax.swing.JLabel jLabel7;
	private javax.swing.JLabel jLabel8;
	private javax.swing.JLabel jLabel9;
	private javax.swing.JPanel jPanel1;
	private javax.swing.JPanel jPanel2;
	private javax.swing.JPanel jPanel3;
	private javax.swing.JPanel jPanel4;
	private javax.swing.JPanel jPanel5;
	private javax.swing.JPanel jPanel6;
	private javax.swing.JTabbedPane jTabbedPane1;
	private javax.swing.JTextField jTextField1;
	private javax.swing.JTextField jTextField10;
	private javax.swing.JTextField jTextField11;
	private javax.swing.JTextField jTextField12;
	private javax.swing.JTextField jTextField13;
	private javax.swing.JTextField jTextField14;
	private javax.swing.JTextField jTextField15;
	private javax.swing.JTextField jTextField16;
	private javax.swing.JTextField jTextField17;
	private javax.swing.JTextField jTextField18;
	private javax.swing.JTextField jTextField19;
	private javax.swing.JTextField jTextField2;
	private javax.swing.JTextField jTextField20;
	private javax.swing.JTextField jTextField21;
	private javax.swing.JTextField jTextField22;
	private javax.swing.JTextField jTextField3;
	private javax.swing.JTextField jTextField4;
	private javax.swing.JTextField jTextField5;
	private javax.swing.JTextField jTextField6;
	private javax.swing.JTextField jTextField7;
	private javax.swing.JTextField jTextField8;
	private javax.swing.JTextField jTextField9;
	// End of variables declaration//GEN-END:variables

}