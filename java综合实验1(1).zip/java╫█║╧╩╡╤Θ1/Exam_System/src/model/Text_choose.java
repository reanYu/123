package model;

import java.io.Serializable;

public class Text_choose implements Serializable {
	private String id;
	private String topic;
	private String Option_A;
	private String Option_B;
	private String Option_C;
	private String Option_D;
	private String answer;
	public Text_choose(String id, String topic, String optionA, String optionB,
			String optionC, String optionD, String answer) {
		super();
		this.id = id;
		this.topic = topic;
		Option_A = optionA;
		Option_B = optionB;
		Option_C = optionC;
		Option_D = optionD;
		answer = answer;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getTopic() {
		return topic;
	}
	public void setTopic(String topic) {
		this.topic = topic;
	}
	public String getOption_A() {
		return Option_A;
	}
	public void setOption_A(String optionA) {
		Option_A = optionA;
	}
	public String getOption_B() {
		return Option_B;
	}
	public void setOption_B(String optionB) {
		Option_B = optionB;
	}
	public String getOption_C() {
		return Option_C;
	}
	public void setOption_C(String optionC) {
		Option_C = optionC;
	}
	public String getOption_D() {
		return Option_D;
	}
	public void setOption_D(String optionD) {
		Option_D = optionD;
	}
	public void setAnswer(String answer) {
		this.answer = answer;
	}
	public String getAnswer() {
		return answer;
	}

}
