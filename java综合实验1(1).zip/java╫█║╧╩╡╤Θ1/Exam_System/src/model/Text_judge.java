package model;

import java.io.Serializable;

public class Text_judge implements Serializable {
     private String id;
     private String topic;
     private String answer;
	public Text_judge(String id, String topic, String answer) {
		super();
		this.id = id;
		this.topic = topic;
		this.answer = answer;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getTopic() {
		return topic;
	}
	public void setTopic(String topic) {
		this.topic = topic;
	}
	public void setAnswer(String answer) {
		this.answer = answer;
	}
	public String getAnswer() {
		return answer;
	}
     
}
