package model;

import java.io.Serializable;

public class Text_multiselect implements Serializable {
       private String id;
       private String topic;
       private String OptionA;
       private String OptionB;
       private String OptionC;
       private String OptionD;
       private String OptionE;
       private String answer1;
       private String answer2;
	public Text_multiselect(String id, String topic, String optionA,
			String optionB, String optionC, String optionD, String OptionE,String answer1, String answer2) {
		super();
		this.id = id;
		this.topic = topic;
		OptionA = optionA;
		OptionB = optionB;
		OptionC = optionC;
		OptionD = optionD;
		this.OptionE = OptionE;
		this.answer1=answer1;
		this.answer2=answer2;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getTopic() {
		return topic;
	}
	public void setTopic(String topic) {
		this.topic = topic;
	}
	public String getOptionA() {
		return OptionA;
	}
	public void setOptionA(String optionA) {
		OptionA = optionA;
	}
	public String getOptionB() {
		return OptionB;
	}
	public void setOptionB(String optionB) {
		OptionB = optionB;
	}
	public String getOptionC() {
		return OptionC;
	}
	public void setOptionC(String optionC) {
		OptionC = optionC;
	}
	public String getOptionD() {
		return OptionD;
	}
	public void setOptionD(String optionD) {
		OptionD = optionD;
	}
	public void setAnswer1(String answer1) {
		this.answer1 = answer1;
	}
	public String getAnswer1() {
		return answer1;
	}
	public void setOptionE(String optionE) {
		OptionE = optionE;
	}
	public String getOptionE() {
		return OptionE;
	}
	public void setAnswer2(String answer2) {
		this.answer2 = answer2;
	}
	public String getAnswer2() {
		return answer2;
	}
       
}
