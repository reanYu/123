package model;

import java.io.IOException;
import java.io.Serializable;
import java.net.UnknownHostException;
import java.util.ArrayList;

import server.Client;

public class Text_paper implements Serializable{
	private String id;
	private String name;
	private String time;
	public Text_paper(String id,String name,String time) {
		super();
		this.id = id;
		this.name = name;
		this.time = time;
	}
	
	public Text_paper() {
		// TODO Auto-generated constructor stub
	}

	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getTime() {
		return time;
	}
	public void setTime(String time) {
		this.time = time;
	}
	public ArrayList<Text_paper> viewData2() throws UnknownHostException, IOException, ClassNotFoundException{
		Client c = new Client();
		return c.viewData2();
	}

}
