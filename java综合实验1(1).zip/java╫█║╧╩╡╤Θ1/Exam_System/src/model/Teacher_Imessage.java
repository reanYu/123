package model;

import java.io.IOException;
import java.io.Serializable;
import java.net.UnknownHostException;
import java.util.ArrayList;

import server.Client;

public class Teacher_Imessage implements Serializable {
        private String id;
        private String name;
        private String pw;
        private String head_photo;
		public Teacher_Imessage(String id, String name, String pw, String headPhoto) {
			super();
			this.id = id;
			this.name = name;
			this.pw = pw;
			head_photo = headPhoto;
		}
		public Teacher_Imessage() {
			// TODO Auto-generated constructor stub
		}
		public String getId() {
			return id;
		}
		public void setId(String id) {
			this.id = id;
		}
		public String getName() {
			return name;
		}
		public void setName(String name) {
			this.name = name;
		}
		public String getPw() {
			return pw;
		}
		public void setPw(String pw) {
			this.pw = pw;
		}
		public String getHead_photo() {
			return head_photo;
		}
		public void setHead_photo(String headPhoto) {
			head_photo = headPhoto;
		}
        
		protected void SetNewStudent(){
			
		}
        protected void ManageStudent(){
			
		}
        protected void ShowStudent(){
	
        }
        protected void DeleteStudent(){
	
        }
        public ArrayList<Teacher_Imessage> viewData1() throws UnknownHostException, IOException, ClassNotFoundException{
			Client c = new Client();
			return c.viewData1();
		}
}
