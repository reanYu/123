package model;

import java.io.IOException;
import java.io.Serializable;
import java.net.UnknownHostException;
import java.util.ArrayList;

import server.Client;

public class Exam_results implements Serializable {
	private String id;
	private String name;
	private String results;
	private String gradepoint;
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getResults() {
		return results;
	}
	public void setResults(String results) {
		this.results = results;
	}
	public Exam_results(String id, String name, String results, String gradepoint) {
		super();
		this.id = id;
		this.name = name;
		this.results = results;
		this.gradepoint =gradepoint;
	}
	public Exam_results() {
		// TODO Auto-generated constructor stub
	}
	
	public ArrayList<Exam_results> viewData3() throws UnknownHostException, IOException, ClassNotFoundException{
		Client c = new Client();
		return c.viewData3();
	}
	public void setGradepoint(String gradepoint) {
		this.gradepoint = gradepoint;
	}
	public String getGradepoint() {
		return gradepoint;
	}

}
