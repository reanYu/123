package model;

import java.io.Serializable;

public class Admin_Imessage implements Serializable {
        private String id;
        private String name;
        private String pw;
        private String head_photo;
		public Admin_Imessage(String id, String name, String pw, String headPhoto) {
			super();
			this.id = id;
			this.name = name;
			this.pw = pw;
			head_photo = headPhoto;
		}
		public String getId() {
			return id;
		}
		public void setId(String id) {
			this.id = id;
		}
		public String getName() {
			return name;
		}
		public void setName(String name) {
			this.name = name;
		}
		public String getPw() {
			return pw;
		}
		public void setPw(String pw) {
			this.pw = pw;
		}
		public String getHead_photo() {
			return head_photo;
		}
		public void setHead_photo(String headPhoto) {
			head_photo = headPhoto;
		}
        protected void SetNewTeacher(){
        	
        }
        protected void ManageTeacher(){
        	
        }
        protected void ShowTeacher(){
        	
        }
        protected void DeleteTeacher(){
        	
        }
}
