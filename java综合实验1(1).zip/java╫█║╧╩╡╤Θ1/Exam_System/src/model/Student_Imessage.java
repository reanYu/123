package model;

import java.io.IOException;
import java.io.Serializable;
import java.net.UnknownHostException;
import java.util.ArrayList;

import server.Client;


public class Student_Imessage implements Serializable {
        private String id;
        private String pw;
        private String name;
        private String head_photo;
      
		public Student_Imessage(String id, String pw, String name, String headPhoto) {
			super();
			this.id = id;
			this.pw = pw;
			this.name = name;
			head_photo = headPhoto;
			
		}
		public Student_Imessage() {
			// TODO Auto-generated constructor stub
		}
		public String getId() {
			return id;
		}
		public void setId(String id) {
			this.id = id;
		}
		public String getPw() {
			return pw;
		}
		public void setPw(String pw) {
			this.pw = pw;
		}
		public String getName() {
			return name;
		}
		public void setName(String name) {
			this.name = name;
		}
		public String getHead_photo() {
			return head_photo;
		}
		public void setHead_photo(String headPhoto) {
			head_photo = headPhoto;
		}
		public ArrayList<Student_Imessage> viewData() throws UnknownHostException, IOException, ClassNotFoundException{
			Client c = new Client();
			return c.viewData();
		}
}
		