/*
Navicat MySQL Data Transfer

Source Server         : localhost_3306
Source Server Version : 50018
Source Host           : localhost:3306
Source Database       : exam_system

Target Server Type    : MYSQL
Target Server Version : 50018
File Encoding         : 65001

Date: 2019-01-03 20:40:38
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for admin_imessage
-- ----------------------------
DROP TABLE IF EXISTS `admin_imessage`;
CREATE TABLE `admin_imessage` (
  `id` int(20) NOT NULL,
  `name` varchar(20) default NULL,
  `pw` varchar(20) default NULL,
  `head_photo` varchar(100) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of admin_imessage
-- ----------------------------
INSERT INTO `admin_imessage` VALUES ('555', '555', '555', '555');

-- ----------------------------
-- Table structure for exam_results
-- ----------------------------
DROP TABLE IF EXISTS `exam_results`;
CREATE TABLE `exam_results` (
  `id` varchar(30) NOT NULL,
  `name` varchar(30) default NULL,
  `results` varchar(30) default NULL,
  `gradepoint` varchar(30) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;

-- ----------------------------
-- Records of exam_results
-- ----------------------------
INSERT INTO `exam_results` VALUES ('172017777', '小刘', '60', '1');

-- ----------------------------
-- Table structure for img
-- ----------------------------
DROP TABLE IF EXISTS `img`;
CREATE TABLE `img` (
  `uname` varchar(255) default NULL,
  `f.getName` varchar(255) default NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of img
-- ----------------------------

-- ----------------------------
-- Table structure for student_imessage
-- ----------------------------
DROP TABLE IF EXISTS `student_imessage`;
CREATE TABLE `student_imessage` (
  `id` varchar(20) NOT NULL,
  `name` varchar(20) default NULL,
  `pw` varchar(20) default NULL,
  `head_photo` varchar(100) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of student_imessage
-- ----------------------------
INSERT INTO `student_imessage` VALUES ('111', '123', '123', '111');
INSERT INTO `student_imessage` VALUES ('172017210', '小刘', '111111', '123');
INSERT INTO `student_imessage` VALUES ('222', '222', '222', '222');
INSERT INTO `student_imessage` VALUES ('666', '666', '666', '666');

-- ----------------------------
-- Table structure for teacher_imessage
-- ----------------------------
DROP TABLE IF EXISTS `teacher_imessage`;
CREATE TABLE `teacher_imessage` (
  `id` varchar(20) NOT NULL,
  `name` varchar(20) default NULL,
  `pw` varchar(20) default NULL,
  `head_photo` varchar(100) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of teacher_imessage
-- ----------------------------
INSERT INTO `teacher_imessage` VALUES ('123', '123', '123', '123');
INSERT INTO `teacher_imessage` VALUES ('333', '333', '333', '333');

-- ----------------------------
-- Table structure for text_choose
-- ----------------------------
DROP TABLE IF EXISTS `text_choose`;
CREATE TABLE `text_choose` (
  `id` varchar(100) NOT NULL,
  `topic` varchar(100) default NULL,
  `option_A` varchar(100) default NULL,
  `option_B` varchar(100) default NULL,
  `option_C` varchar(100) default NULL,
  `option_D` varchar(100) default NULL,
  `answer` varchar(100) default NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of text_choose
-- ----------------------------
INSERT INTO `text_choose` VALUES ('4', 'java编程语言是由哪个公司创立的', 'Sun', 'Google', 'IBM', 'Gateway', 'Sun');

-- ----------------------------
-- Table structure for text_fill
-- ----------------------------
DROP TABLE IF EXISTS `text_fill`;
CREATE TABLE `text_fill` (
  `id` varchar(100) NOT NULL,
  `topic` varchar(100) default NULL,
  `answer` varchar(100) default NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of text_fill
-- ----------------------------
INSERT INTO `text_fill` VALUES ('2', '计算机系统一般由那两大系统组成？', '软件系统和硬件系统');

-- ----------------------------
-- Table structure for text_judge
-- ----------------------------
DROP TABLE IF EXISTS `text_judge`;
CREATE TABLE `text_judge` (
  `id` varchar(100) NOT NULL,
  `topic` varchar(100) default NULL,
  `answer` varchar(100) default NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of text_judge
-- ----------------------------
INSERT INTO `text_judge` VALUES ('3', '计算机能直接识别汇编语言程序', '错误');

-- ----------------------------
-- Table structure for text_multiselect
-- ----------------------------
DROP TABLE IF EXISTS `text_multiselect`;
CREATE TABLE `text_multiselect` (
  `id` varchar(100) NOT NULL,
  `topic` varchar(100) default NULL,
  `option_A` varchar(100) default NULL,
  `option_B` varchar(100) default NULL,
  `option_C` varchar(100) default NULL,
  `option_D` varchar(100) default NULL,
  `option_E` varchar(100) default NULL,
  `answer1` varchar(255) default NULL,
  `answer2` varchar(255) default NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of text_multiselect
-- ----------------------------
INSERT INTO `text_multiselect` VALUES ('1', '指令系统中控制程序流程的指令通常有', '传送指令', '比较指令', '转移指令', 'i/o指令', '返回指令', '转移指令', '返回指令');

-- ----------------------------
-- Table structure for text_paper
-- ----------------------------
DROP TABLE IF EXISTS `text_paper`;
CREATE TABLE `text_paper` (
  `id` varchar(30) default NULL,
  `name` varchar(30) default NULL,
  `time` varchar(30) default NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of text_paper
-- ----------------------------
INSERT INTO `text_paper` VALUES ('1', 'java程序设计实训', '0.5');
INSERT INTO `text_paper` VALUES ('2', '语文', '1');
INSERT INTO `text_paper` VALUES ('3', '英语', '1');
INSERT INTO `text_paper` VALUES ('4', '计算机基础', '0.03');
